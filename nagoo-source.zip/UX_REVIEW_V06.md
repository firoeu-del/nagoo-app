# UX review — v0.6

## Pass 1 — information architecture
- Removed the long settings form from the core setup path.
- Split word configuration into a dedicated Deck Builder.
- Made all team/player naming optional.

## Pass 2 — visual hierarchy
- Reduced global accent noise.
- Team colors now identify turns and gameplay state.
- Removed dashboard-like stat cards from Home.
- Reduced gameplay HUD density.

## Pass 3 — interaction
- Core setup is tap-only.
- Large primary targets are at least ~40–62pt high.
- Correct answer remains the biggest target: the entire word card.
- Skip is visually secondary and disabled state is obvious.

## Pass 4 — small screens / RTL
- Added compact layouts below 700pt height for Gameplay and Team cards.
- Kept primary navigation and labels RTL-aware.
- Scrolling is limited to content-heavy Deck/Custom screens and mode carousel.

## Pass 5 — safety / content state
- +18 pack requires explicit confirmation.
- Last active pack/level cannot be removed accidentally if it would leave the game with no word source.
- Custom pack has an explicit active/inactive state once it contains words.
