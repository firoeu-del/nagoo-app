# Nagoo! v0.5 Content System

## Built-in bank
6,157 deduplicated words across 14 built-in categories.

| Pack | Words |
|---|---:|
| عمومی | 446 |
| سینما | 308 |
| افراد مشهور | 294 |
| ورزش | 295 |
| غذا | 356 |
| اشیا | 354 |
| مکان‌ها | 423 |
| چالش‌ها | 343 |
| +۱۸ بزرگسال | 328 |
| ایرانی‌ها | 645 |
| نوستالژی | 466 |
| موزیک | 484 |
| برندها | 607 |
| شغل‌ها | 808 |

## Difficulty matrix
Every built-in pack has content at all three levels. The user can independently enable Easy, Medium and Hard for each category. A category with no active level is treated as disabled.

## Selection behavior
- Category sizes do not affect how often a category appears; active categories are balanced.
- Immediate category repetition is avoided when possible.
- Exact word IDs do not repeat until the active pool cycles.
- Normalized duplicate text is also blocked across categories during the cycle.
- Difficulty selection is limited to the user-enabled levels only.

## Adult pack
The adult pack is explicitly opt-in and contains direct sexual, anatomical and slang terms. It never enters a normal game unless the user confirms the +18 warning and enables the pack.
