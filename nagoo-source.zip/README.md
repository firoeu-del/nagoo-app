# نگو! — Party Game

**Current UI:** v1.0.0 Mockup Parity — bright, playful, social party-game design matching the approved concept mockups.

A Persian RTL party game for 2–6 two-player teams. One word is shown at a time; the active player describes it without saying the word or its derivatives. Correct answers pass the phone immediately. When the round bomb expires, the team holding the phone loses reserve time. The last team with time remaining wins.

## v0.9 focus — Bright Social Party UI
This release replaces the dark digital/arcade visual direction with a warm, light and playful party-game system inspired by real social play. The game logic stays intact, while the main flow is rebuilt around brighter surfaces, friendlier team colors, safer Persian typography, and clearer touch targets.

### Main flow
Home → Teams → Before Start → Word Packs → Gameplay → Explosion → Winner

### Highlights
- warm cream/light backgrounds across the whole app
- cheerful coral, purple, sky-blue, mint, orange and yellow accents
- Vazirmatn throughout with generous Persian line-height and vertical padding
- gameplay correct-answer action is limited to the circular word target only
- deterministic word font sizing based on text length instead of blind auto-fit
- long gameplay words support up to 3 lines with large vertical glyph safety
- colorful team reserve meters visible during play
- brighter handoff, pause, explosion and winner states
- 2–6 two-player teams
- Classic, Mystery Bomb and Turbo modes
- per-pack Easy / Medium / Hard selection
- explicit opt-in 18+ pack
- custom word packs
- smart balanced word selection
- sound + haptic feedback
- pause/background-safe timers

## Run
```bash
npm install
npx expo install --fix
npx expo start --dev-client --lan --port 8082 --clear
```

v0.9 adds no new native package compared with v0.8, so an existing v0.8 Development Build normally only needs Metro after dependencies are installed.
