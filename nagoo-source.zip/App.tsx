import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Platform, StatusBar, View } from 'react-native';
import { useFonts, Vazirmatn_400Regular, Vazirmatn_500Medium, Vazirmatn_600SemiBold, Vazirmatn_700Bold, Vazirmatn_800ExtraBold, Vazirmatn_900Black } from '@expo-google-fonts/vazirmatn';
import * as SystemUI from 'expo-system-ui';
import { setAudioModeAsync } from 'expo-audio';
import { words } from './src/data/words';
import { aliveTeams, applyCorrectAnswer, applyRoundLoss, applySkip, nextAliveTeamIndex } from './src/game/engine';
import { createWordSelectionMemory, pickSmartWord, resetWordSelectionMemory } from './src/game/wordSelector';
import { gameModes, resolveRoundSeconds } from './src/game/modes';
import { GameScreen } from './src/screens/GameScreen';
import { HomeScreen } from './src/screens/HomeScreen';
import { ResultsScreen } from './src/screens/ResultsScreen';
import { RulesScreen } from './src/screens/RulesScreen';
import { CustomWordsScreen } from './src/screens/CustomWordsScreen';
import { SettingsScreen } from './src/screens/SettingsScreen';
import { PacksScreen } from './src/screens/PacksScreen';
import { TeamsScreen } from './src/screens/TeamsScreen';
import { CustomWord, GameSettings, GameWord, ScreenName, TeamDraft, TeamState, WordCategory, WordDifficulty } from './src/types';
import { loadCustomWords, loadSettings, loadTeams, saveCustomWords, saveSettings, saveTeams } from './src/storage';
import { teamPalette, theme } from './src/theme';

void SystemUI.setBackgroundColorAsync(theme.colors.bg);

function createTeams(count: number, previous: TeamDraft[] = []): TeamDraft[] {
  return Array.from({ length: count }, (_, index) => previous[index] ?? ({
    id: `team-${index + 1}`,
    title: `تیم ${index + 1}`,
    player1: '',
    player2: '',
    color: teamPalette[index],
  }));
}

const CONTENT_VERSION = 6;
const newContentPacks: WordCategory[] = ['iran', 'nostalgia', 'music', 'brands', 'jobs'];
const allDifficulties: WordDifficulty[] = ['normal', 'hard', 'veryHard'];
const defaultDifficultyMatrix = Object.fromEntries([
  'general','iran','nostalgia','cinema','music','famous','sports','food','brands','jobs','objects','places','hard','adult','custom'
].map((category) => [category, [...allDifficulties]])) as GameSettings['difficultyMatrix'];

const initialSettings: GameSettings = {
  contentVersion: CONTENT_VERSION,
  reserveSeconds: 100,
  roundSeconds: 20,
  skipUnlockSeconds: 5,
  categories: ['general', 'iran', 'nostalgia', 'cinema', 'music', 'famous', 'sports', 'food', 'brands', 'jobs', 'objects', 'places', 'hard'],
  difficultyMatrix: defaultDifficultyMatrix,
  gameMode: 'classic',
  hardWordBonuses: true,
  soundEnabled: true,
  hapticsEnabled: true,
};

export default function App() {
  const [fontsLoaded] = useFonts({ Vazirmatn_400Regular, Vazirmatn_500Medium, Vazirmatn_600SemiBold, Vazirmatn_700Bold, Vazirmatn_800ExtraBold, Vazirmatn_900Black });

  useEffect(() => {
    void setAudioModeAsync({ playsInSilentMode: true }).catch(() => undefined);
  }, []);

  useEffect(() => {
    if (Platform.OS !== 'web') return;
    const browser = globalThis as typeof globalThis & {
      navigator?: { serviceWorker?: { register: (url: string) => Promise<unknown> } };
    };
    void browser.navigator?.serviceWorker?.register('/service-worker.js').catch(() => undefined);
  }, []);

  const [screen, setScreen] = useState<ScreenName>('home');
  const [teamDrafts, setTeamDrafts] = useState<TeamDraft[]>(() => createTeams(2));
  const [settings, setSettings] = useState(initialSettings);
  const [customWords, setCustomWords] = useState<CustomWord[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [teams, setTeams] = useState<TeamState[]>([]);
  const [currentTeamIndex, setCurrentTeamIndex] = useState(0);
  const [roundNumber, setRoundNumber] = useState(1);
  const [activeRoundSeconds, setActiveRoundSeconds] = useState(20);
  const [overlay, setOverlay] = useState<null | { title: string; body: string; eliminated: boolean }>(null);
  const wordSelection = useRef(createWordSelectionMemory());

  useEffect(() => {
    let active = true;
    Promise.all([loadCustomWords(), loadSettings(), loadTeams()]).then(([storedWords, storedSettings, storedTeams]) => {
      if (!active) return;
      setCustomWords(storedWords);
      if (storedSettings) {
        const needsContentMigration = (storedSettings.contentVersion ?? 0) < CONTENT_VERSION;
        const migrated = needsContentMigration
          ? Array.from(new Set([...storedSettings.categories, ...newContentPacks]))
          : storedSettings.categories;
        const categories = storedWords.length
          ? migrated
          : migrated.filter((category) => category !== 'custom');
        const storedMatrix = storedSettings.difficultyMatrix ?? {};
        const difficultyMatrix = { ...defaultDifficultyMatrix, ...storedMatrix };
        const gameMode = storedSettings.gameMode ?? 'classic';
        setSettings({
          ...initialSettings,
          ...storedSettings,
          contentVersion: CONTENT_VERSION,
          categories: categories.length ? categories : ['general'],
          difficultyMatrix,
          gameMode,
          roundSeconds: gameModes[gameMode].roundSeconds,
          skipUnlockSeconds: gameModes[gameMode].skipUnlockSeconds,
        });
      }
      if (storedTeams && storedTeams.length >= 2 && storedTeams.length <= 6) setTeamDrafts(storedTeams);
      setHydrated(true);
    });
    return () => { active = false; };
  }, []);

  useEffect(() => { if (hydrated) void saveSettings(settings); }, [hydrated, settings]);
  useEffect(() => { if (hydrated) void saveTeams(teamDrafts); }, [hydrated, teamDrafts]);
  useEffect(() => { if (hydrated) void saveCustomWords(customWords); }, [customWords, hydrated]);

  useEffect(() => {
    if (customWords.length > 0 || !settings.categories.includes('custom')) return;
    setSettings((current) => ({
      ...current,
      categories: current.categories.filter((category) => category !== 'custom').length
        ? current.categories.filter((category) => category !== 'custom')
        : ['general'],
    }));
  }, [customWords.length, settings.categories]);

  const allWords = useMemo<GameWord[]>(() => [
    ...words,
    ...customWords.map((word) => ({ ...word, category: 'custom' as const })),
  ], [customWords]);

  const eligibleWords = useMemo(
    () => allWords.filter((word) => settings.categories.includes(word.category) && (settings.difficultyMatrix[word.category] ?? allDifficulties).includes(word.difficulty)),
    [allWords, settings.categories, settings.difficultyMatrix],
  );

  const pickWord = useCallback((): GameWord => {
    const fallback = words.filter((word) => word.category === 'general');
    const source = eligibleWords.length ? eligibleWords : fallback;
    return pickSmartWord(source, wordSelection.current);
  }, [eligibleWords]);

  const [currentWord, setCurrentWord] = useState<GameWord>(() => words[0]);

  const startGame = useCallback(() => {
    const nextTeams: TeamState[] = teamDrafts.map((team, index) => ({
      ...team,
      title: team.title.trim() || `تیم ${index + 1}`, 
      remaining: settings.reserveSeconds,
      eliminated: false,
      losses: 0,
      describerIndex: 0,
      correctAnswers: 0,
      skips: 0,
      bonusSeconds: 0,
      eliminatedRound: null,
    }));
    setTeams(nextTeams);
    setCurrentTeamIndex(0);
    setRoundNumber(1);
    setActiveRoundSeconds(resolveRoundSeconds(settings.gameMode));
    setOverlay(null);
    resetWordSelectionMemory(wordSelection.current);
    setCurrentWord(pickWord());
    setScreen('game');
  }, [pickWord, settings.gameMode, settings.reserveSeconds, teamDrafts]);

  const handleCorrect = () => {
    const withRotatedDescriber = teams.map((team, index) =>
      index === currentTeamIndex
        ? { ...team, describerIndex: (team.describerIndex === 0 ? 1 : 0) as 0 | 1 }
        : team,
    );
    const updated = applyCorrectAnswer(withRotatedDescriber, currentTeamIndex, currentWord, settings.reserveSeconds, settings.hardWordBonuses);
    const nextIndex = nextAliveTeamIndex(updated, currentTeamIndex);
    setTeams(updated);
    setCurrentTeamIndex(nextIndex);
    setCurrentWord(pickWord());
  };

  const handleSkip = () => {
    setTeams((current) => applySkip(current, currentTeamIndex));
    setCurrentWord(pickWord());
  };

  const handleRoundExpired = useCallback(() => {
    if (overlay) return;
    const penalized = applyRoundLoss(teams, currentTeamIndex, activeRoundSeconds, roundNumber);
    const loser = penalized[currentTeamIndex];
    const remainingAlive = aliveTeams(penalized);
    setTeams(penalized);

    if (remainingAlive.length === 1) {
      setScreen('results');
      setOverlay(null);
      return;
    }

    setOverlay({
      title: loser.eliminated ? `${loser.title} حذف شد!` : `بمب دست ${loser.title} ترکید!`,
      body: loser.eliminated
        ? 'زمان این تیم به صفر رسید. گوشی را به تیم بعدی بده.'
        : `${Math.ceil(activeRoundSeconds)} ثانیه از ذخیره‌ی این تیم کم شد. ${loser.remaining} ثانیه باقی مانده.`,
      eliminated: loser.eliminated,
    });
  }, [activeRoundSeconds, currentTeamIndex, overlay, roundNumber, teams]);

  const handleStartNextRound = () => {
    const currentWasEliminated = teams[currentTeamIndex]?.eliminated;
    const nextIndex = currentWasEliminated ? nextAliveTeamIndex(teams, currentTeamIndex) : currentTeamIndex;
    setCurrentTeamIndex(nextIndex);
    setRoundNumber((value) => value + 1);
    setActiveRoundSeconds(resolveRoundSeconds(settings.gameMode));
    setCurrentWord(pickWord());
    setOverlay(null);
  };

  const quitGame = () => {
    setOverlay(null);
    setScreen('settings');
  };

  const winner = aliveTeams(teams)[0] ?? teams.slice().sort((a, b) => b.remaining - a.remaining)[0];

  if (!fontsLoaded) return <View style={{ flex: 1, backgroundColor: theme.colors.bg }} />;

  return (
    <>
      <StatusBar barStyle="dark-content" backgroundColor={theme.colors.bg} />
      {screen === 'home' && <HomeScreen onStart={() => setScreen('teams')} onRules={() => setScreen('rules')} />}
      {screen === 'rules' && <RulesScreen onBack={() => setScreen('home')} onStart={() => setScreen('teams')} />}
      {screen === 'teams' && (
        <TeamsScreen
          teams={teamDrafts}
          onChangeCount={(count) => setTeamDrafts((prev) => createTeams(count, prev))}
          onChangeTeam={(index, patch) => setTeamDrafts((prev) => prev.map((team, i) => i === index ? { ...team, ...patch } : team))}
          onBack={() => setScreen('home')}
          onNext={() => setScreen('settings')}
        />
      )}
      {screen === 'settings' && (
        <SettingsScreen
          settings={settings}
          onChange={setSettings}
          onBack={() => setScreen('teams')}
          onStart={startGame}
          onOpenPacks={() => setScreen('packs')}
          teamCount={teamDrafts.length}
        />
      )}
      {screen === 'packs' && (
        <PacksScreen settings={settings} onChange={setSettings} onBack={() => setScreen('settings')} onCustom={() => setScreen('custom')} customCount={customWords.length} />
      )}
      {screen === 'custom' && (
        <CustomWordsScreen words={customWords} onChange={setCustomWords} onBack={() => setScreen('packs')} />
      )}
      {screen === 'game' && teams.length > 0 && (
        <GameScreen
          teams={teams}
          currentTeamIndex={currentTeamIndex}
          settings={settings}
          roundSeconds={activeRoundSeconds}
          hiddenClock={gameModes[settings.gameMode].hiddenClock}
          word={currentWord}
          roundNumber={roundNumber}
          overlay={overlay}
          onCorrect={handleCorrect}
          onSkip={handleSkip}
          onRoundExpired={handleRoundExpired}
          onStartNextRound={handleStartNextRound}
          onQuit={quitGame}
        />
      )}
      {screen === 'results' && winner && (
        <ResultsScreen
          winner={winner}
          teams={teams}
          soundEnabled={settings.soundEnabled}
          hapticsEnabled={settings.hapticsEnabled}
          onRematch={startGame}
          onEditTeams={() => setScreen('teams')}
        />
      )}
    </>
  );
}
