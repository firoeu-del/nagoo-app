# UX Review v0.9 — Bright Social Party UI

## Non-negotiable changes implemented
1. No dark primary backgrounds in the main game flow.
2. Correct answer is only triggered by pressing the circular word target.
3. Gameplay word typography no longer relies on automatic shrinking that can crop Persian glyphs.
4. Main Persian text uses larger line-height plus vertical padding and avoids fixed-height text boxes.
5. Word pack and team labels permit multiple lines where truncation would harm comprehension.
6. Result details use a taller scrollable sheet rather than a partially visible half-sheet.

## Visual direction
Warm cream background, white/cream cards, coral primary identity, purple CTA, and colorful team accents. The intent is social, friendly and playful rather than digital/futuristic.
