# Nagoo! v0.7 — Art Direction

## Product feel
Nagoo! is a party game, not a settings utility. The interface should feel like a live game stage: immediate, bold, rhythmic, and easy to read while a phone is moving between people.

## Core rule
Every primary screen has one dominant decision or action. Secondary information must never compete with the game state.

## Visual direction
- Neo Party / Arcade Minimal
- Near-black canvas, warm white type, team colors used only when they carry meaning
- Flat shapes and restrained borders instead of stacked glass cards
- Large Vazirmatn headlines with short Persian copy
- No decorative English kickers in the primary flow
- No generic dashboard statistics on Home

## Interaction hierarchy
1. Word / current team / bomb pressure
2. Primary action
3. Optional context
4. Settings and detailed stats

## Screen principles
### Home
One brand moment, one gameplay object, one launch action.

### Teams
Team count first. Team identity is visual. Naming is optional and collapsed by default.

### Lobby
Only mode, reserve time, and word deck are primary decisions.

### Deck Builder
Pack selection is a visual grid. Difficulty controls belong to the currently focused pack, not every card at once.

### Gameplay
The word owns the screen. The HUD stays small. The countdown becomes visually dominant only in the last five seconds.

### Explosion
A transition, not a report. It auto-advances and can be tapped to skip.

### Winner
Celebration first. Detailed standings are opt-in.

## Typography
Vazirmatn only:
- Black / ExtraBold: hero type, word, team identity
- Bold / SemiBold: controls and labels
- Medium / Regular: supporting copy

## Color
Brand coral is not a universal fill. Team color should tint the live game scene, handoff, explosion, and winner moments. Difficulty colors stay consistent: green / yellow / coral.

## v0.8 text safety
- Persian display type must use generous line height (roughly 1.35×–1.55× at large sizes).
- Do not place Vazirmatn labels inside exact-height containers unless the line height is explicitly safe.
- Use `minHeight` for semantic controls; reserve fixed height for icon-only/number-only elements.
- Critical game words may wrap to 3 lines and use `adjustsFontSizeToFit`; never hard-clip the answer word.
- Team/pack names should wrap to 2 lines where space permits.
- Bottom sheets must scroll when content can exceed the viewport.
- Circular hero containers need extra inset padding near curved edges; metadata should never sit on the clipping arc.
- Important text uses a conservative `maxFontSizeMultiplier` to protect the party-game composition on iOS.
