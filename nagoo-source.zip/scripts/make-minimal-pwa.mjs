import { createHash } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const sourceDir = path.resolve('dist');
const outputDir = path.resolve('dist-minimal');

await fs.rm(outputDir, { recursive: true, force: true });
await fs.cp(sourceDir, outputDir, { recursive: true });

const bundleDir = path.join(outputDir, '_expo', 'static', 'js', 'web');
const [bundleName] = (await fs.readdir(bundleDir)).filter((name) => name.endsWith('.js'));
const bundlePath = path.join(bundleDir, bundleName);
let bundle = await fs.readFile(bundlePath, 'utf8');

async function walk(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(absolute));
    else files.push(absolute);
  }
  return files;
}

const assetsDir = path.join(outputDir, 'assets');
for (const assetPath of await walk(assetsDir)) {
  const relativeUrl = `/${path.relative(outputDir, assetPath).split(path.sep).join('/')}`;
  const extension = path.extname(assetPath).toLowerCase();
  const mime = extension === '.ttf' ? 'font/ttf' : extension === '.wav' ? 'audio/wav' : 'application/octet-stream';
  const dataUrl = `data:${mime};base64,${(await fs.readFile(assetPath)).toString('base64')}`;
  bundle = bundle.split(relativeUrl).join(dataUrl);
}

let html = await fs.readFile(path.join(outputDir, 'index.html'), 'utf8');
const bundleUrl = `/_expo/static/js/web/${bundleName}`;
html = html.replace(
  new RegExp(`<script[^>]+src=["']${bundleUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}["'][^>]*><\\/script>`),
  () => `<script>${bundle.split('</script').join('<\\/script')}</script>`,
);
await fs.writeFile(path.join(outputDir, 'index.html'), html);

await fs.rm(path.join(outputDir, '_expo'), { recursive: true, force: true });
await fs.rm(assetsDir, { recursive: true, force: true });
await fs.rm(path.join(outputDir, 'metadata.json'), { force: true });

const swPath = path.join(outputDir, 'service-worker.js');
const remainingFiles = (await walk(outputDir))
  .filter((file) => file !== swPath && !['_headers', '_redirects'].includes(path.basename(file)))
  .sort();
const precache = ['/', ...remainingFiles.map((file) => `/${path.relative(outputDir, file).split(path.sep).join('/')}`)];
const digest = createHash('sha256');
for (const file of remainingFiles) digest.update(await fs.readFile(file));

let serviceWorker = await fs.readFile(swPath, 'utf8');
serviceWorker = serviceWorker
  .replace(/nagoo-pwa-[a-f0-9]{12}/, `nagoo-pwa-min-${digest.digest('hex').slice(0, 12)}`)
  .replace(/const PRECACHE_URLS = \[[\s\S]*?\];/, `const PRECACHE_URLS = ${JSON.stringify(precache, null, 2)};`);
await fs.writeFile(swPath, serviceWorker);

console.log(`Minimal PWA ready: ${(await walk(outputDir)).length} files`);
