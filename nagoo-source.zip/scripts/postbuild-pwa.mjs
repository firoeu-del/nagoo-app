import { createHash } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const distDir = path.resolve('dist');
const indexPath = path.join(distDir, 'index.html');
const swPath = path.join(distDir, 'service-worker.js');

async function walk(directory) {
  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(absolute));
    else files.push(absolute);
  }
  return files;
}

let html = await fs.readFile(indexPath, 'utf8');
html = html
  .replace(/<html[^>]*>/i, '<html lang="fa" dir="rtl">')
  .replace(/<meta name="viewport"[^>]*>/i, '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover, user-scalable=no">')
  .replace('</head>', `  <link rel="manifest" href="/manifest.webmanifest">
  <link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
  <meta name="theme-color" content="#FFF3D5">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="نگو!">
  <meta name="apple-mobile-web-app-status-bar-style" content="default">
  <meta name="mobile-web-app-capable" content="yes">
  <style>
    html, body, #root { width: 100%; height: 100%; margin: 0; }
    html, body { background: #FFF3D5; overscroll-behavior: none; }
    body { position: fixed; inset: 0; overflow: hidden; -webkit-user-select: none; user-select: none; -webkit-tap-highlight-color: transparent; }
    input, textarea { -webkit-user-select: text; user-select: text; }
  </style>
</head>`);
await fs.writeFile(indexPath, html);

const files = (await walk(distDir))
  .filter((file) => file !== swPath && !['_headers', '_redirects'].includes(path.basename(file)))
  .sort();
const precache = files.map((file) => `/${path.relative(distDir, file).split(path.sep).join('/')}`);
if (!precache.includes('/')) precache.unshift('/');

const digest = createHash('sha256');
for (const file of files) digest.update(await fs.readFile(file));
const cacheName = `nagoo-pwa-${digest.digest('hex').slice(0, 12)}`;

let serviceWorker = await fs.readFile(swPath, 'utf8');
serviceWorker = serviceWorker
  .replace('__NAGOO_CACHE__', cacheName)
  .replace('/*__NAGOO_PRECACHE__*/[]', JSON.stringify(precache, null, 2));
await fs.writeFile(swPath, serviceWorker);

console.log(`PWA ready: ${precache.length} files precached (${cacheName})`);
