import { createHash } from 'node:crypto';
import { promises as fs } from 'node:fs';
import path from 'node:path';

const sourceDir = path.resolve('dist-minimal');
const outputDir = path.resolve('dist-workers-upload');

await fs.rm(outputDir, { recursive: true, force: true });
await fs.mkdir(outputDir, { recursive: true });

let html = await fs.readFile(path.join(sourceDir, 'index.html'), 'utf8');
html = html
  .replace(/<link rel="icon"[^>]*>/i, '')
  .replace(/<link rel="apple-touch-icon"[^>]*>/i, '<link rel="apple-touch-icon" href="/icon.png">');
await fs.writeFile(path.join(outputDir, 'index.html'), html);

await fs.copyFile(path.join(sourceDir, 'icons', 'icon-512.png'), path.join(outputDir, 'icon.png'));

const manifest = {
  name: 'نگو! — بازی دورهمی',
  short_name: 'نگو!',
  description: 'بازی گروهی فارسی برای دورهمی‌ها',
  lang: 'fa',
  dir: 'rtl',
  id: '/',
  start_url: '/',
  scope: '/',
  display: 'standalone',
  orientation: 'portrait',
  background_color: '#FFF3D5',
  theme_color: '#FFF3D5',
  icons: [{ src: '/icon.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }],
};
await fs.writeFile(path.join(outputDir, 'manifest.webmanifest'), JSON.stringify(manifest, null, 2));

const digest = createHash('sha256').update(html).digest('hex').slice(0, 12);
const serviceWorker = `const CACHE_NAME = 'nagoo-workers-${digest}';
const PRECACHE = ['/', '/index.html', '/manifest.webmanifest', '/icon.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith('nagoo-') && key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
    if (response.ok && new URL(event.request.url).origin === self.location.origin) {
      const copy = response.clone();
      event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)));
    }
    return response;
  })).catch(() => event.request.mode === 'navigate' ? caches.match('/') : Response.error()));
});
`;
await fs.writeFile(path.join(outputDir, 'service-worker.js'), serviceWorker);

console.log('Workers Upload package ready: 4 files');
