# Nagoo! v1.0 — Mockup Parity Pass

This version translates the approved bright mockups into the React Native product UI.

## Visual rules
- Warm cream / butter-yellow background on all main screens.
- White/cream elevated cards with soft amber shadows.
- Coral/orange display headings.
- Purple glossy primary CTAs.
- Saturated team colors with white outlines.
- Vazirmatn across all Persian text.
- Critical Persian text uses intentionally generous line-height and vertical padding.

## Screen parity
- Home: sticker logo, central circular sample word, team/difficulty chips, hint, purple start CTA.
- Teams: count selector, saturated team cards, paired avatars, selected-team panel.
- Before Start: three large mode cards, reserve-time cards, word-pack summary, sound/haptic/bonus toggles.
- Packs: two-column pastel pack grid with icon circles, selected states, difficulty dock.
- Rules: three large numbered cards plus compact rule notes.
- Gameplay: team time bars, large circular correct-answer target, separate hint, purple skip button, bottom stop control shelf.
- Results: celebratory headline, winner, trophy, purple rematch button, compact score preview and full results sheet.

## Interaction requirement
The correct-answer action is bound only to the central word circle in `GameScreen.tsx`. Background taps do not count as correct answers.
