# v1.1.0 — Mockup Parity Rebuild
- Rebuilt the visual system against approved mockup references.
- Reworked Home, Teams, Lobby, Packs, Rules, Gameplay and Results.
- Removed the white tile behind the main logo.
- Replaced gameplay reserve bars with compact team status cards.
- Added avatar tokens around the word arena.
- Correct answer remains limited to the word circle only.
- Removed the gameplay word line clamp to avoid text clipping.

# Changelog

## 1.0.0 — Mockup Parity UI
- Rebuilt the visual system to match the approved bright party-game mockups.
- Rebuilt Home, Teams, Before Start, Packs, Rules, Gameplay and Winner/Results layouts.
- Added warm cream backgrounds, pastel cards, saturated team colors and purple glossy CTAs.
- Gameplay now follows the approved structure: team meters → circular word target → hint → skip → control shelf.
- Correct answer is triggered only by tapping the word circle.
- Increased Persian line-height/padding and adaptive word sizing to reduce glyph clipping.
- Kept Vazirmatn as the app-wide typeface.
- Preserved game engine, round timing, skip lock, haptics/audio, difficulty matrix and word database behavior.
