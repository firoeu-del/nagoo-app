# Nagoo! v1.1 — Mockup parity rebuild

This pass treats the approved generated mockups as a visual specification rather than loose inspiration.

## Rebuilt
- Sticker-style brand mark without the white square tile
- Denser playful light background and confetti system
- Mockup-style purple primary CTA with inset action bubble
- Home hero proportions, orbit tokens and hint treatment
- Team count rail, compact colored team cards and selected-team editor card
- Pre-game mode cards, reserve-time cards and settings controls
- Pack cards with larger icon medallions and stronger pastel surfaces
- Rules cards with clearer number/icon hierarchy
- Gameplay team cards, dotted circular arena, player avatars, separate hint and two primary actions
- Winner trophy/ribbon composition, player avatars and celebration hierarchy

## Interaction guarantee
The correct-answer callback is attached only to the central word-circle Pressable.

## Text safety
The central gameplay word has no numberOfLines limit. Font size is length-aware and the circular arena does not clip overflow.
