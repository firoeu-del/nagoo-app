# Nagoo! v0.8 — Micro Polish + Text Safety

## Primary goal
Move v0.7 from a strong art-direction prototype to a device-safe party-game UI. The main defect observed on iPhone was Persian text clipping caused by tight line heights, fixed-height containers, and crowded overlays.

## Text-safety rules
- Vazirmatn display text receives generous line height and a small vertical safety pad.
- Critical gameplay/display text uses controlled font scaling to protect composition.
- Long team names and game words use adaptive fitting instead of hard clipping.
- Team and pack names may wrap to two lines where meaningful.
- The gameplay word can use up to three lines with a lower minimum font scale for long Persian phrases.
- Bottom sheets and standings scroll instead of overflowing.
- Fixed-height controls are reserved for numbers/icons; semantic text containers use minHeight.

## Visual polish
- Home word bomb reduced and metadata moved inward from the circular clipping edge.
- Lobby controls became denser and less dashboard-like.
- Deck difficulty dock is now part of normal layout, not an overlapping absolute panel.
- Gameplay halo/HUD reduced so the word has more breathing room.
- Rules and results use shorter copy and safer hierarchy.

## Content hygiene
A tiny denylist removes unexplained technical brand acronyms that feel broken in a party context. This is intentionally conservative so the large content bank remains intact.
