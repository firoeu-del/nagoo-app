import React, { useMemo, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { PrimaryButton, Screen, SectionTitle, TopNav } from '../components/UI';
import { BrandMark } from '../components/BrandMark';
import { categoryArt, difficultyMeta, playableCategories } from '../data/categoryMeta';
import { categoryCounts, categoryDifficultyCounts } from '../data/words';
import { theme } from '../theme';
import { GameSettings, WordCategory, WordDifficulty } from '../types';

const levels: WordDifficulty[] = ['normal', 'hard', 'veryHard'];
const emoji: Partial<Record<WordCategory, string>> = {
  general: '🌍', iran: '🗼', nostalgia: '📺', cinema: '🎬', music: '🎧', famous: '🌟', sports: '⚽️', food: '🍔', brands: '🛍️', jobs: '💼', objects: '🛋️', places: '🗺️', hard: '🧠', adult: '🔞', custom: '✍️',
};
const bg: Partial<Record<WordCategory, string>> = {
  general: '#EDF5FF', iran: '#FFF2C9', nostalgia: '#E9FBF7', cinema: '#F1E9FF', music: '#F7E9FF', famous: '#FFE9EF', sports: '#E8F9EE', food: '#FFF1D5', brands: '#FFE9F1', jobs: '#EAF2FF', objects: '#FFF0E6', places: '#ECF9ED', hard: '#F4E9FF', adult: '#FFF0C9', custom: '#E8F8FF',
};

const labels: Record<WordCategory, string> = {
  general: 'عمومی', cinema: 'سینما', famous: 'افراد مشهور', sports: 'ورزش', food: 'غذا', objects: 'اشیا', places: 'مکان‌ها', hard: 'چالش‌ها', adult: '۱۸+ بزرگسال', iran: 'ایرانی‌ها', nostalgia: 'نوستالژی', music: 'موزیک', brands: 'برندها', jobs: 'شغل‌ها', custom: 'پک خودمون',
};

export function PacksScreen({ settings, onChange, onBack, onCustom, customCount }: {
  settings: GameSettings;
  onChange: (settings: GameSettings) => void;
  onBack: () => void;
  onCustom: () => void;
  customCount: number;
}) {
  const [focused, setFocused] = useState<WordCategory>(settings.categories.includes('adult') ? 'adult' : settings.categories[0] ?? 'general');
  const selectedWords = useMemo(() => settings.categories.reduce((sum, category) => sum + (categoryCounts[category] ?? 0), 0), [settings.categories]);

  const setCategory = (category: WordCategory, active: boolean) => {
    const categories = active ? Array.from(new Set([...settings.categories, category])) : settings.categories.filter((item) => item !== category);
    if (!categories.length) return;
    onChange({ ...settings, categories, difficultyMatrix: { ...settings.difficultyMatrix, [category]: settings.difficultyMatrix[category]?.length ? settings.difficultyMatrix[category] : [...levels] } });
  };
  const toggleCategory = (category: WordCategory) => {
    const active = settings.categories.includes(category);
    if (category === 'adult' && !active) {
      Alert.alert('پک +۱۸', 'این پک شامل واژه‌ها و اصطلاحات صریح بزرگسالانه است.', [
        { text: 'لغو', style: 'cancel' },
        { text: 'من ۱۸+ هستم', style: 'destructive', onPress: () => { setCategory(category, true); setFocused(category); } },
      ]);
      return;
    }
    setCategory(category, !active);
  };
  const toggleLevel = (category: WordCategory, level: WordDifficulty) => {
    const current = settings.difficultyMatrix[category] ?? [...levels];
    const next = current.includes(level) ? current.filter((item) => item !== level) : [...current, level];
    const categories = next.length ? Array.from(new Set([...settings.categories, category])) : settings.categories.filter((item) => item !== category);
    if (!categories.length) return;
    onChange({ ...settings, categories, difficultyMatrix: { ...settings.difficultyMatrix, [category]: next } });
  };

  const focusedArt = categoryArt[focused];
  const focusedActive = settings.categories.includes(focused);
  const selectedLevels = settings.difficultyMatrix[focused] ?? levels;

  return (
    <Screen style={styles.screen}>
      <TopNav onBack={onBack} />
      <View style={styles.brand}><BrandMark size={49} /></View>
      <SectionTitle center title="پک کلمات" subtitle="پک‌ها رو انتخاب کن؛ سختی پک انتخاب‌شده پایین صفحه تنظیم می‌شه." />
      <View style={styles.summary}><Text maxFontSizeMultiplier={1} style={styles.summaryText}>{settings.categories.length.toLocaleString('fa-IR')} پک</Text><View style={styles.summaryDot} /><Text maxFontSizeMultiplier={1} style={styles.summaryText}>{selectedWords.toLocaleString('fa-IR')} کلمه آماده</Text></View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scroll} contentContainerStyle={styles.grid}>
        {playableCategories.filter((category) => category !== 'adult').map((category) => {
          const art = categoryArt[category];
          const active = settings.categories.includes(category);
          const isFocused = focused === category;
          return (
            <Pressable key={category} onPress={() => setFocused(category)} style={({ pressed }) => [styles.pack, { backgroundColor: bg[category] ?? '#FFF8E9' }, active && { borderColor: `${art.accent}90` }, isFocused && { borderWidth: 2.5 }, pressed && styles.pressed]}>
              <View style={[styles.iconCircle, { backgroundColor: `${art.accent}22` }]}><Text style={styles.iconEmoji}>{emoji[category] ?? '●'}</Text></View>
              <View style={styles.packCopy}><Text numberOfLines={2} maxFontSizeMultiplier={1} style={[styles.packName, { color: active ? art.accent : theme.colors.textStrong }]}>{labels[category]}</Text><Text maxFontSizeMultiplier={1} style={styles.packCount}>{(categoryCounts[category] ?? 0).toLocaleString('fa-IR')} کلمه</Text></View>
              <Pressable onPress={(event) => { event.stopPropagation(); toggleCategory(category); }} style={[styles.selectCircle, active && { backgroundColor: art.accent, borderColor: art.accent }]}><Text style={[styles.selectMark, active && { color: '#fff' }]}>{active ? '✓' : ''}</Text></Pressable>
            </Pressable>
          );
        })}
        <Pressable onPress={onCustom} style={({ pressed }) => [styles.pack, { backgroundColor: '#E8F8FF', borderStyle: 'dashed', borderColor: '#6BCBF3' }, pressed && styles.pressed]}>
          <View style={[styles.iconCircle, { backgroundColor: '#DDF5FF' }]}><Text style={styles.iconEmoji}>✍️</Text></View>
          <View style={styles.packCopy}><Text maxFontSizeMultiplier={1} style={[styles.packName, { color: theme.colors.blue }]}>پک خودمون</Text><Text maxFontSizeMultiplier={1} style={styles.packCount}>{customCount ? `${customCount.toLocaleString('fa-IR')} کلمه` : 'کلمات مخصوص جمع'}</Text></View>
          <View style={styles.selectCircle}><Text style={styles.selectMark}>›</Text></View>
        </Pressable>
      </ScrollView>

      <View style={[styles.focusDock, { backgroundColor: focused === 'adult' ? '#FFEBAF' : (bg[focused] ?? '#FFF4D7'), borderColor: `${focusedArt.accent}66` }]}>
        <View style={styles.focusHead}>
          <View style={[styles.adultBadge, { backgroundColor: focusedArt.accent }]}><Text maxFontSizeMultiplier={1} style={styles.adultBadgeText}>{focused === 'adult' ? '18+' : (emoji[focused] ?? '●')}</Text></View>
          <View style={styles.focusCopy}><Text numberOfLines={2} maxFontSizeMultiplier={1} style={[styles.focusName, { color: focusedArt.accent }]}>{labels[focused]}</Text><Text numberOfLines={2} maxFontSizeMultiplier={1} style={styles.focusBlurb}>{focusedArt.blurb}</Text></View>
          <Pressable onPress={() => toggleCategory(focused)} style={[styles.focusToggle, focusedActive && { backgroundColor: theme.colors.green }]}><Text maxFontSizeMultiplier={1} style={[styles.focusToggleText, focusedActive && { color: '#fff' }]}>{focusedActive ? 'روشن' : 'خاموش'}</Text></Pressable>
        </View>
        <View style={styles.levelRail}>
          {levels.map((level) => {
            const active = focusedActive && selectedLevels.includes(level);
            return (
              <Pressable key={level} disabled={!focusedActive} onPress={() => toggleLevel(focused, level)} style={({ pressed }) => [styles.level, active && { borderColor: difficultyMeta[level].color, backgroundColor: '#FFFDF8' }, !focusedActive && { opacity: 0.4 }, pressed && styles.pressed]}>
                <Text maxFontSizeMultiplier={1} style={[styles.levelName, { color: active ? difficultyMeta[level].color : theme.colors.muted }]}>{difficultyMeta[level].label}</Text>
                <Text maxFontSizeMultiplier={1} style={styles.levelCount}>{(categoryDifficultyCounts[focused]?.[level] ?? 0).toLocaleString('fa-IR')}</Text>
                <View style={[styles.levelCheck, active && { backgroundColor: difficultyMeta[level].color, borderColor: difficultyMeta[level].color }]}><Text style={[styles.levelCheckText, active && { color: '#fff' }]}>{active ? '✓' : ''}</Text></View>
              </Pressable>
            );
          })}
        </View>
      </View>
      <PrimaryButton label="تمام" onPress={onBack} compact icon="★" />
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingBottom: 8 }, brand: { alignItems: 'center', marginTop: -26, marginBottom: -8, zIndex: 3 }, pressed: { opacity: 0.84, transform: [{ scale: 0.985 }] },
  summary: { alignSelf: 'center', minHeight: 42, borderRadius: 21, backgroundColor: '#FFFDF8', borderWidth: 1.3, borderColor: theme.colors.border, flexDirection: 'row-reverse', alignItems: 'center', gap: 9, paddingHorizontal: 16, marginTop: -5, marginBottom: 9, shadowColor: '#C68A53', shadowOpacity: .06, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } },
  summaryText: { color: theme.colors.blue, fontFamily: theme.fonts.black, fontSize: 10.5, lineHeight: 22, writingDirection: 'rtl' }, summaryDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: theme.colors.orange },
  scroll: { flex: 1, marginBottom: 7 }, grid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 9, paddingBottom: 10 },
  pack: { width: '48.7%', minHeight: 101, borderRadius: 22, borderWidth: 1.5, borderColor: theme.colors.border, padding: 10, flexDirection: 'row-reverse', alignItems: 'center', gap: 8, shadowColor: '#BD8156', shadowOpacity: .09, shadowRadius: 9, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  iconCircle: { width: 57, height: 57, borderRadius: 29, borderWidth: 3, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#8D684D', shadowOpacity: .08, shadowRadius: 5, shadowOffset: { width: 0, height: 3 } }, iconEmoji: { fontSize: 31 },
  packCopy: { flex: 1, minWidth: 0, alignItems: 'flex-end' }, packName: { maxWidth: '100%', fontFamily: theme.fonts.black, fontSize: 14.5, lineHeight: 30, textAlign: 'right', writingDirection: 'rtl', paddingVertical: 1 }, packCount: { color: theme.colors.text, fontFamily: theme.fonts.bold, fontSize: 8.5, lineHeight: 17, writingDirection: 'rtl' },
  selectCircle: { position: 'absolute', bottom: 8, left: 9, width: 27, height: 27, borderRadius: 14, borderWidth: 2, borderColor: '#DCCFC4', backgroundColor: 'rgba(255,255,255,.9)', alignItems: 'center', justifyContent: 'center' }, selectMark: { color: theme.colors.text, fontFamily: theme.fonts.black, fontSize: 13, lineHeight: 18 },
  focusDock: { flexShrink: 0, borderRadius: 27, borderWidth: 1.8, paddingHorizontal: 12, paddingVertical: 11, marginBottom: 7, shadowColor: '#C68A53', shadowOpacity: .12, shadowRadius: 11, shadowOffset: { width: 0, height: 6 } },
  focusHead: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10 }, adultBadge: { width: 58, height: 58, borderRadius: 29, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#9A6845', shadowOpacity: .10, shadowRadius: 7, shadowOffset: { width: 0, height: 4 } }, adultBadgeText: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 16.5, lineHeight: 29 },
  focusCopy: { flex: 1, minWidth: 0, alignItems: 'flex-end' }, focusName: { maxWidth: '100%', fontFamily: theme.fonts.black, fontSize: 16.5, lineHeight: 32, textAlign: 'right', writingDirection: 'rtl' }, focusBlurb: { maxWidth: '100%', color: theme.colors.textStrong, fontFamily: theme.fonts.medium, fontSize: 9, lineHeight: 19, textAlign: 'right', writingDirection: 'rtl' },
  focusToggle: { minWidth: 66, minHeight: 40, borderRadius: 20, borderWidth: 1.5, borderColor: theme.colors.borderStrong, backgroundColor: '#FFFDF8', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 10 }, focusToggleText: { color: theme.colors.text, fontFamily: theme.fonts.black, fontSize: 9.7, lineHeight: 20, writingDirection: 'rtl' },
  levelRail: { flexDirection: 'row-reverse', gap: 8, marginTop: 10 }, level: { flex: 1, minWidth: 0, minHeight: 49, borderRadius: 21, borderWidth: 1.7, borderColor: theme.colors.border, backgroundColor: 'rgba(255,255,255,.84)', flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 4, paddingHorizontal: 5 }, levelName: { flexShrink: 1, fontFamily: theme.fonts.black, fontSize: 9.2, lineHeight: 19, writingDirection: 'rtl' }, levelCount: { color: theme.colors.muted2, fontFamily: theme.fonts.bold, fontSize: 7.4, lineHeight: 15 }, levelCheck: { width: 21, height: 21, borderRadius: 11, borderWidth: 1.5, borderColor: '#D8C7B9', alignItems: 'center', justifyContent: 'center' }, levelCheckText: { color: theme.colors.muted, fontFamily: theme.fonts.black, fontSize: 10, lineHeight: 15 },
});
