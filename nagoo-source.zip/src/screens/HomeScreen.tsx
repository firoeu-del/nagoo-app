import React, { useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View, useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BrandMark } from '../components/BrandMark';
import { PrimaryButton, Screen, TopNav } from '../components/UI';
import { teamPalette, theme } from '../theme';

const samples = ['آسانسور', 'آفتاب‌پرست', 'پیتزا', 'پرسپولیس'];

export function HomeScreen({ onStart, onRules }: { onStart: () => void; onRules: () => void }) {
  const pulse = useRef(new Animated.Value(0)).current;
  const fade = useRef(new Animated.Value(1)).current;
  const [sampleIndex, setSampleIndex] = useState(0);
  const { width, height } = useWindowDimensions();
  const circle = Math.min(width * 0.67, height * 0.315, 300);

  useEffect(() => {
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 1350, useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: 1350, useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  useEffect(() => {
    const id = setInterval(() => {
      Animated.timing(fade, { toValue: 0, duration: 120, useNativeDriver: true }).start(() => {
        setSampleIndex((value) => (value + 1) % samples.length);
        Animated.timing(fade, { toValue: 1, duration: 180, useNativeDriver: true }).start();
      });
    }, 2700);
    return () => clearInterval(id);
  }, [fade]);

  const circleScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.018] });
  return (
    <Screen style={styles.screen}>
      <TopNav rightLabel="قوانین" onRight={onRules} />

      <View style={styles.brandBlock}>
        <BrandMark size={124} />
        <Text maxFontSizeMultiplier={1} style={styles.tagline}>بگو، ولی خودش رو نگو.</Text>
        <View style={[styles.brandDot, { backgroundColor: theme.colors.primary }]} />
      </View>

      <View style={styles.hero}>
        <Animated.View style={[styles.orbitGlow, { width: circle + 66, height: circle + 66, borderRadius: (circle + 66) / 2, transform: [{ scale: circleScale }] }]} />
        <Animated.View style={[styles.dashedOrbit, { width: circle + 42, height: circle + 42, borderRadius: (circle + 42) / 2, transform: [{ scale: circleScale }] }]} />
        <LinearGradient colors={['#FFFDF8', '#FFF1CE']} style={[styles.wordCircle, { width: circle, height: circle, borderRadius: circle / 2 }]}> 
          <View style={styles.metaRail}>
            <View style={[styles.metaPill, { backgroundColor: '#E9FBEA', borderColor: '#C7EDCD' }]}><Text style={[styles.dot, { color: teamPalette[2] }]}>●</Text><Text maxFontSizeMultiplier={1} style={[styles.metaText, { color: '#2B8A4E' }]}>تیم سبز</Text></View>
            <View style={[styles.metaPill, { backgroundColor: '#FFF0E7', borderColor: '#FFD9C9' }]}><Text style={[styles.dot, { color: theme.colors.coral }]}>●</Text><Text maxFontSizeMultiplier={1} style={[styles.metaText, { color: theme.colors.coral }]}>آسان</Text></View>
          </View>
          <Animated.Text numberOfLines={2} maxFontSizeMultiplier={1} style={[styles.sampleWord, { opacity: fade, fontSize: circle > 275 ? 43 : 39, lineHeight: circle > 275 ? 82 : 74 }]}>{samples[sampleIndex]}</Animated.Text>
          <View style={styles.wave}><View style={styles.waveDash}/><View style={styles.waveDash}/><View style={styles.waveDash}/></View>
        </LinearGradient>

        {[
          { color: teamPalette[0], p: { top: 15, left: '50%' } },
          { color: teamPalette[1], p: { top: '30%', left: 1 } },
          { color: teamPalette[3], p: { top: '30%', right: 1 } },
          { color: teamPalette[4], p: { bottom: 60, left: 17 } },
          { color: teamPalette[2], p: { bottom: 60, right: 17 } },
          { color: theme.colors.purple, p: { bottom: 14, left: '50%' } },
        ].map((orb, index) => <View key={index} style={[styles.orb, orb.p as any, { backgroundColor: orb.color, marginLeft: orb.p.left === '50%' ? -20 : undefined }]} />)}

        <View style={styles.hintCard}><Text style={styles.hintIcon}>☝️</Text><Text maxFontSizeMultiplier={1} style={styles.hintText}>حدس زد؟ خودِ کلمه رو لمس کن</Text></View>
      </View>

      <View style={styles.footer}>
        <PrimaryButton label="شروع بازی" onPress={onStart} icon="▶" />
        <Pressable onPress={onRules} style={({ pressed }) => [styles.helper, pressed && { opacity: 0.6 }]}><Text maxFontSizeMultiplier={1} style={styles.helperText}>اولین بازی؟ قوانین رو ۳۰ ثانیه ببین  ●</Text></Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { justifyContent: 'space-between', paddingBottom: 14 },
  brandBlock: { alignItems: 'center', marginTop: -4, zIndex: 3 },
  tagline: { color: theme.colors.textStrong, fontFamily: theme.fonts.bold, fontSize: 19, lineHeight: 38, writingDirection: 'rtl', textAlign: 'center', paddingVertical: 3, marginTop: -5 },
  brandDot: { width: 18, height: 18, borderRadius: 9, marginTop: 8, borderWidth: 4, borderColor: '#FFFDF8', shadowColor: '#D66E72', shadowOpacity: .16, shadowRadius: 7, shadowOffset: { width: 0, height: 4 } },
  hero: { flex: 1, minHeight: 405, alignItems: 'center', justifyContent: 'center', marginTop: -4 },
  orbitGlow: { position: 'absolute', backgroundColor: 'rgba(255,202,72,0.11)' },
  dashedOrbit: { position: 'absolute', borderWidth: 1.4, borderColor: 'rgba(255,104,72,0.23)', borderStyle: 'dashed' },
  wordCircle: { borderWidth: 3.5, borderColor: theme.colors.coral, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 26, shadowColor: '#D5914E', shadowOpacity: 0.14, shadowRadius: 17, shadowOffset: { width: 0, height: 9 }, elevation: 5 },
  metaRail: { position: 'absolute', top: 28, left: 20, right: 20, flexDirection: 'row-reverse', justifyContent: 'space-between' },
  metaPill: { minHeight: 35, borderRadius: 19, paddingHorizontal: 11, flexDirection: 'row-reverse', alignItems: 'center', gap: 6, borderWidth: 1.3 }, dot: { fontSize: 13, lineHeight: 18 }, metaText: { fontFamily: theme.fonts.black, fontSize: 10.5, lineHeight: 23, writingDirection: 'rtl' },
  sampleWord: { width: '100%', color: '#E75116', fontFamily: theme.fonts.black, textAlign: 'center', writingDirection: 'rtl', paddingVertical: 16, letterSpacing: -0.8 },
  wave: { position: 'absolute', bottom: 35, flexDirection: 'row', gap: 4 }, waveDash: { width: 12, height: 4, borderRadius: 3, backgroundColor: theme.colors.purple, transform: [{ rotate: '7deg' }] },
  orb: { position: 'absolute', width: 40, height: 40, borderRadius: 20, borderWidth: 5, borderColor: '#FFFDF8', shadowColor: '#9F6943', shadowOpacity: 0.16, shadowRadius: 7, shadowOffset: { width: 0, height: 4 }, elevation: 4 },
  hintCard: { position: 'absolute', bottom: -3, minHeight: 50, borderRadius: 25, backgroundColor: '#FFFDF8', borderWidth: 1.7, borderColor: '#FFD1C6', paddingHorizontal: 16, flexDirection: 'row-reverse', alignItems: 'center', gap: 9, shadowColor: '#B77E55', shadowOpacity: 0.08, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } }, hintIcon: { fontSize: 22 }, hintText: { color: theme.colors.textStrong, fontFamily: theme.fonts.bold, fontSize: 11.2, lineHeight: 25, writingDirection: 'rtl', paddingVertical: 3 },
  footer: { gap: 6, zIndex: 3 }, helper: { minHeight: 34, alignItems: 'center', justifyContent: 'center' }, helperText: { color: theme.colors.muted, fontFamily: theme.fonts.medium, fontSize: 9.6, lineHeight: 20, writingDirection: 'rtl' },
});
