import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { PrimaryButton, Screen, SectionTitle, TopNav } from '../components/UI';
import { BrandMark } from '../components/BrandMark';
import { categoryCounts } from '../data/words';
import { gameModes } from '../game/modes';
import { theme } from '../theme';
import { GameMode, GameSettings } from '../types';

const reserveOptions = [60, 80, 100, 120, 160];
const modeOrder: GameMode[] = ['classic', 'mystery', 'turbo'];
const modeIcon: Record<GameMode, string> = { classic: '👑', mystery: '💣', turbo: '🚀' };
const modeAccent: Record<GameMode, string> = { classic: '#FF6848', mystery: '#8D5CF6', turbo: '#3AB6EC' };

function ToggleCard({ active, color, label, icon, onPress }: { active: boolean; color: string; label: string; icon: string; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.toggleCard, pressed && styles.pressed]}><Text style={styles.toggleIcon}>{icon}</Text><Text style={styles.toggleLabel}>{label}</Text><View style={[styles.switch, active && { backgroundColor: `${color}20`, borderColor: color }]}><View style={[styles.switchKnob, { backgroundColor: active ? color : '#D2C6B9', transform: [{ translateX: active ? -12 : 0 }] }]} /></View></Pressable>;
}

export function SettingsScreen({ settings, onChange, onBack, onStart, onOpenPacks, teamCount }: {
  settings: GameSettings; onChange: (next: GameSettings) => void; onBack: () => void; onStart: () => void; onOpenPacks: () => void; teamCount: number;
}) {
  const selectedWords = settings.categories.reduce((sum, category) => sum + (categoryCounts[category] ?? 0), 0);
  const setMode = (mode: GameMode) => onChange({ ...settings, gameMode: mode, roundSeconds: gameModes[mode].roundSeconds, skipUnlockSeconds: gameModes[mode].skipUnlockSeconds });
  return (
    <Screen style={styles.screen}>
      <TopNav onBack={onBack} />
      <View style={styles.brand}><BrandMark size={50} /></View>
      <SectionTitle center title="قبل شروع" subtitle="مود، زمان و کلمات؛ فقط همین سه چیز رو انتخاب کن." />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>• مود بازی •</Text>
          <View style={styles.modeRail}>{modeOrder.map((mode, index) => { const active = settings.gameMode === mode; const accent = modeAccent[mode]; return <Pressable key={mode} onPress={() => setMode(mode)} style={({ pressed }) => [styles.mode, active && { borderColor: accent, borderWidth: 3 }, pressed && styles.pressed]}>{active ? <View style={styles.check}><Text style={styles.checkText}>✓</Text></View> : null}<Text style={styles.modeEmoji}>{modeIcon[mode]}</Text><Text style={[styles.modeNumber, { color: accent }]}>{(index + 1).toLocaleString('fa-IR')}</Text><View style={[styles.modeLabelPill, active && { backgroundColor: accent }]}><Text style={[styles.modeName, active && { color: '#fff' }]}>{gameModes[mode].title}</Text></View></Pressable>; })}</View>
        </View>

        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>• زمان ذخیره •</Text>
          <View style={styles.timeRail}>{reserveOptions.map(seconds => { const active = settings.reserveSeconds === seconds; return <Pressable key={seconds} onPress={() => onChange({ ...settings, reserveSeconds: seconds })} style={({ pressed }) => [styles.time, active && styles.timeActive, pressed && styles.pressed]}>{active && seconds === 60 ? <Text style={styles.timerEmoji}>⏱️</Text> : null}<Text style={[styles.timeValue, active && styles.timeValueActive]}>{seconds.toLocaleString('fa-IR')}</Text><Text style={[styles.timeLabel, active && styles.timeLabelActive]}>ثانیه</Text></Pressable>; })}</View>
        </View>

        <Pressable onPress={onOpenPacks} style={({ pressed }) => [styles.deckCard, pressed && styles.pressed]}>
          <Text style={styles.deckEmoji}>🗂️</Text><View style={styles.deckCopy}><Text style={styles.deckTitle}>• کلمات بازی •</Text><Text style={styles.deckMeta}>{settings.categories.length.toLocaleString('fa-IR')} پک  ·  {selectedWords.toLocaleString('fa-IR')} کلمه</Text></View><View style={styles.deckArrow}><Text style={styles.deckArrowText}>‹</Text></View>
        </Pressable>

        <View style={styles.toggleRow}><ToggleCard active={settings.soundEnabled} color={theme.colors.primaryStrong} label="صدا" icon="🔊" onPress={() => onChange({ ...settings, soundEnabled: !settings.soundEnabled })} /><ToggleCard active={settings.hapticsEnabled} color={theme.colors.violet} label="هپتیک" icon="📳" onPress={() => onChange({ ...settings, hapticsEnabled: !settings.hapticsEnabled })} /><ToggleCard active={settings.hardWordBonuses} color={theme.colors.green} label="بونس سختی" icon="🎁" onPress={() => onChange({ ...settings, hardWordBonuses: !settings.hardWordBonuses })} /></View>
        <View style={styles.summary}><Text style={styles.summaryEmoji}>🎉</Text><Text style={styles.summaryText}>{teamCount.toLocaleString('fa-IR')} تیم  •  {gameModes[settings.gameMode].title}  •  {settings.reserveSeconds.toLocaleString('fa-IR')} ثانیه</Text></View>
      </ScrollView>
      <PrimaryButton label="شروع بازی" onPress={onStart} icon="✦" />
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingBottom: 10 }, brand: { alignItems: 'center', marginTop: -26, marginBottom: -8, zIndex: 3 }, scroll: { paddingBottom: 14, gap: 11 }, pressed: { opacity: .84, transform: [{ scale: .985 }] },
  sectionCard: { backgroundColor: '#FFFDF8', borderRadius: 30, borderWidth: 1.5, borderColor: theme.colors.border, padding: 13, shadowColor: '#C68A53', shadowOpacity: .1, shadowRadius: 12, shadowOffset: { width: 0, height: 7 }, elevation: 3 }, sectionTitle: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 17, lineHeight: 34, textAlign: 'center', writingDirection: 'rtl', paddingVertical: 1, marginBottom: 8 },
  modeRail: { flexDirection: 'row-reverse', gap: 9 }, mode: { flex: 1, minHeight: 158, borderRadius: 27, borderWidth: 1.5, borderColor: theme.colors.border, backgroundColor: '#FFFCF8', alignItems: 'center', justifyContent: 'center', padding: 8, shadowColor: '#B3794B', shadowOpacity: .07, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } }, modeEmoji: { fontSize: 46, lineHeight: 56 }, modeNumber: { fontFamily: theme.fonts.black, fontSize: 34, lineHeight: 49, marginTop: -3 }, modeLabelPill: { minHeight: 40, minWidth: '90%', borderRadius: 20, backgroundColor: '#FFF4E9', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 }, modeName: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 11.5, lineHeight: 23, textAlign: 'center', writingDirection: 'rtl' }, check: { position: 'absolute', top: -9, left: -8, width: 36, height: 36, borderRadius: 18, backgroundColor: theme.colors.primaryStrong, alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: '#fff', zIndex: 3 }, checkText: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 17, lineHeight: 24 },
  timeRail: { flexDirection: 'row-reverse', gap: 6 }, time: { flex: 1, minHeight: 85, borderRadius: 24, backgroundColor: '#FFFDF9', borderWidth: 1.5, borderColor: theme.colors.border, alignItems: 'center', justifyContent: 'center', paddingVertical: 5 }, timeActive: { backgroundColor: '#FFF0EC', borderColor: theme.colors.primaryStrong, borderWidth: 3 }, timerEmoji: { fontSize: 16, marginBottom: -3 }, timeValue: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 15.5, lineHeight: 30 }, timeValueActive: { color: theme.colors.primaryStrong, fontSize: 20 }, timeLabel: { color: theme.colors.muted, fontFamily: theme.fonts.bold, fontSize: 8.5, lineHeight: 17 }, timeLabelActive: { color: theme.colors.primaryStrong },
  deckCard: { minHeight: 101, borderRadius: 29, backgroundColor: '#FFFDF8', borderWidth: 1.5, borderColor: theme.colors.border, flexDirection: 'row-reverse', alignItems: 'center', gap: 11, paddingHorizontal: 14, shadowColor: '#C68A53', shadowOpacity: .1, shadowRadius: 11, shadowOffset: { width: 0, height: 6 } }, deckEmoji: { fontSize: 39 }, deckCopy: { flex: 1, minWidth: 0, alignItems: 'flex-end' }, deckTitle: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 17, lineHeight: 32, writingDirection: 'rtl' }, deckMeta: { color: theme.colors.text, fontFamily: theme.fonts.bold, fontSize: 9.5, lineHeight: 19, writingDirection: 'rtl' }, deckArrow: { width: 40, height: 40, borderRadius: 20, borderWidth: 1.5, borderColor: theme.colors.border, backgroundColor: '#FFF9EC', alignItems: 'center', justifyContent: 'center' }, deckArrowText: { color: theme.colors.violet, fontFamily: theme.fonts.black, fontSize: 27, lineHeight: 32 },
  toggleRow: { flexDirection: 'row-reverse', gap: 8 }, toggleCard: { flex: 1, minHeight: 70, borderRadius: 23, backgroundColor: '#FFFDF8', borderWidth: 1.5, borderColor: theme.colors.border, alignItems: 'center', justifyContent: 'center', gap: 2, padding: 6 }, toggleIcon: { fontSize: 21 }, toggleLabel: { color: theme.colors.textStrong, fontFamily: theme.fonts.bold, fontSize: 9.5, lineHeight: 19, writingDirection: 'rtl' }, switch: { width: 41, height: 22, borderRadius: 11, borderWidth: 1.5, borderColor: '#D5C8BE', backgroundColor: '#F4EEE8', padding: 2, justifyContent: 'center', alignItems: 'flex-end' }, switchKnob: { width: 16, height: 16, borderRadius: 8 },
  summary: { minHeight: 40, alignSelf: 'center', borderRadius: 21, backgroundColor: '#FFFDF8', borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row-reverse', alignItems: 'center', gap: 7, paddingHorizontal: 14 }, summaryEmoji: { fontSize: 16 }, summaryText: { color: theme.colors.muted, fontFamily: theme.fonts.bold, fontSize: 9.5, lineHeight: 20, writingDirection: 'rtl' },
});
