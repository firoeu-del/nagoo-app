import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, AppState, AppStateStatus, Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Screen } from '../components/UI';
import { useGameFeedback } from '../hooks/useGameFeedback';
import { theme } from '../theme';
import { GameSettings, GameWord, TeamState } from '../types';

const teamFaces = ['😄','😉','😋','😎','🤩','🥳'];

function wordType(text: string, compact: boolean) {
  const length = [...text.trim()].length;
  let fontSize = compact ? 36 : 43;
  if (length > 10) fontSize = compact ? 32 : 38;
  if (length > 14) fontSize = compact ? 28 : 34;
  if (length > 18) fontSize = compact ? 24 : 30;
  if (length > 23) fontSize = compact ? 21 : 26;
  if (length > 30) fontSize = compact ? 18 : 22;
  return { fontSize, lineHeight: Math.ceil(fontSize * 1.85) };
}

export function GameScreen({
  teams, currentTeamIndex, settings, roundSeconds, hiddenClock, word, roundNumber, overlay,
  onCorrect, onSkip, onRoundExpired, onStartNextRound, onQuit,
}: {
  teams: TeamState[]; currentTeamIndex: number; settings: GameSettings; roundSeconds: number; hiddenClock: boolean; word: GameWord; roundNumber: number;
  overlay: null | { title: string; body: string; eliminated: boolean };
  onCorrect: () => void; onSkip: () => void; onRoundExpired: () => void; onStartNextRound: () => void; onQuit: () => void;
}) {
  const { height: screenHeight, width: screenWidth } = useWindowDimensions();
  const compact = screenHeight < 735;
  const [roundLeft, setRoundLeft] = useState(roundSeconds);
  const [wordAge, setWordAge] = useState(0);
  const [paused, setPaused] = useState(false);
  const [appPaused, setAppPaused] = useState(false);
  const [handoffVisible, setHandoffVisible] = useState(false);

  const team = teams[currentTeamIndex];
  const wordKey = `${team.id}-${word.id}`;
  const describer = team.describerIndex === 0 ? (team.player1 || 'نفر اول') : (team.player2 || 'نفر دوم');
  const guesser = team.describerIndex === 0 ? (team.player2 || 'نفر دوم') : (team.player1 || 'نفر اول');
  const { correct, skip, countdown, boom, select } = useGameFeedback(settings.soundEnabled, settings.hapticsEnabled);

  const wordIn = useRef(new Animated.Value(1)).current;
  const urgencyPulse = useRef(new Animated.Value(0)).current;
  const explosionScale = useRef(new Animated.Value(0.35)).current;
  const explosionFade = useRef(new Animated.Value(0)).current;
  const overlayProgress = useRef(new Animated.Value(0)).current;
  const handoffAnim = useRef(new Animated.Value(0)).current;
  const lastCountdownSecond = useRef<number | null>(null);
  const expiredRef = useRef(false);
  const actionLockedRef = useRef(false);
  const previousTeamIdRef = useRef(team.id);
  const deadlineRef = useRef(Date.now() + roundSeconds * 1000);
  const frozenRemainingRef = useRef(roundSeconds);
  const lastTickRef = useRef(Date.now());
  const pausedRef = useRef(false);
  const appPausedRef = useRef(false);
  const advancedOverlayRef = useRef(false);
  const nextRoundRef = useRef(onStartNextRound);

  useEffect(() => { nextRoundRef.current = onStartNextRound; }, [onStartNextRound]);
  useEffect(() => { pausedRef.current = paused; }, [paused]);
  useEffect(() => { appPausedRef.current = appPaused; }, [appPaused]);

  useEffect(() => {
    setWordAge(0);
    wordIn.setValue(0);
    Animated.spring(wordIn, { toValue: 1, tension: 76, friction: 10, useNativeDriver: true }).start();
    const unlock = setTimeout(() => { actionLockedRef.current = false; }, 250);
    return () => clearTimeout(unlock);
  }, [wordIn, wordKey]);

  useEffect(() => {
    const previousTeamId = previousTeamIdRef.current;
    previousTeamIdRef.current = team.id;
    if (previousTeamId === team.id || overlay) return;
    setHandoffVisible(true);
    handoffAnim.setValue(0);
    Animated.sequence([
      Animated.timing(handoffAnim, { toValue: 1, duration: 90, useNativeDriver: true }),
      Animated.delay(260),
      Animated.timing(handoffAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
    ]).start(() => setHandoffVisible(false));
  }, [handoffAnim, overlay, team.id]);

  useEffect(() => {
    if (overlay) return;
    const now = Date.now();
    deadlineRef.current = now + roundSeconds * 1000;
    frozenRemainingRef.current = roundSeconds;
    lastTickRef.current = now;
    setRoundLeft(roundSeconds);
    setPaused(false);
    pausedRef.current = false;
    lastCountdownSecond.current = null;
    expiredRef.current = false;
  }, [roundNumber, roundSeconds, overlay]);

  useEffect(() => {
    if (overlay || paused || appPaused) return;
    const id = setInterval(() => {
      const now = Date.now();
      const left = Math.max(0, (deadlineRef.current - now) / 1000);
      const delta = Math.max(0, Math.min(0.25, (now - lastTickRef.current) / 1000));
      lastTickRef.current = now;
      setRoundLeft(left);
      setWordAge((value) => value + delta);
    }, 50);
    return () => clearInterval(id);
  }, [appPaused, overlay, paused, roundNumber]);

  useEffect(() => {
    const freezeClock = () => {
      if (pausedRef.current || appPausedRef.current || overlay) return;
      const remaining = Math.max(0, (deadlineRef.current - Date.now()) / 1000);
      frozenRemainingRef.current = remaining;
      setRoundLeft(remaining);
    };
    const onAppStateChange = (nextState: AppStateStatus) => {
      if (nextState !== 'active' && !appPausedRef.current) {
        freezeClock(); appPausedRef.current = true; setAppPaused(true); return;
      }
      if (nextState === 'active' && appPausedRef.current) {
        appPausedRef.current = false; setAppPaused(false);
        if (!pausedRef.current && !overlay) {
          const now = Date.now(); deadlineRef.current = now + frozenRemainingRef.current * 1000; lastTickRef.current = now;
        }
      }
    };
    const subscription = AppState.addEventListener('change', onAppStateChange);
    return () => subscription.remove();
  }, [overlay]);

  useEffect(() => {
    if (overlay || paused || appPaused) return;
    const second = Math.ceil(roundLeft);
    if (second <= 5 && second >= 1 && lastCountdownSecond.current !== second) {
      lastCountdownSecond.current = second;
      countdown(second);
      urgencyPulse.setValue(0);
      Animated.timing(urgencyPulse, { toValue: 1, duration: 340, useNativeDriver: true }).start();
    }
  }, [appPaused, countdown, overlay, paused, roundLeft, urgencyPulse]);

  useEffect(() => {
    if (overlay || paused || appPaused || roundLeft > 0 || expiredRef.current) return;
    expiredRef.current = true; boom(); onRoundExpired();
  }, [appPaused, boom, onRoundExpired, overlay, paused, roundLeft]);

  useEffect(() => {
    if (!overlay) { advancedOverlayRef.current = false; return; }
    advancedOverlayRef.current = false;
    explosionScale.setValue(0.35); explosionFade.setValue(0); overlayProgress.setValue(0);
    Animated.parallel([
      Animated.spring(explosionScale, { toValue: 1, tension: 62, friction: 7, useNativeDriver: true }),
      Animated.timing(explosionFade, { toValue: 1, duration: 190, useNativeDriver: true }),
      Animated.timing(overlayProgress, { toValue: 1, duration: 2100, useNativeDriver: true }),
    ]).start();
    const id = setTimeout(() => {
      if (advancedOverlayRef.current) return;
      advancedOverlayRef.current = true;
      nextRoundRef.current();
    }, 2100);
    return () => clearTimeout(id);
  }, [explosionFade, explosionScale, overlay, overlayProgress]);

  const pauseGame = () => {
    if (paused || overlay) return;
    const remaining = Math.max(0, (deadlineRef.current - Date.now()) / 1000);
    frozenRemainingRef.current = remaining; setRoundLeft(remaining); pausedRef.current = true; setPaused(true); select();
  };
  const resumeGame = () => {
    const now = Date.now(); deadlineRef.current = now + frozenRemainingRef.current * 1000; lastTickRef.current = now; pausedRef.current = false; setPaused(false); select();
  };
  const runLockedAction = (action: () => void) => {
    if (actionLockedRef.current || paused || handoffVisible || overlay) return;
    actionLockedRef.current = true; action(); setTimeout(() => { actionLockedRef.current = false; }, 410);
  };

  const skipRemaining = Math.max(0, settings.skipUnlockSeconds - wordAge);
  const skipEnabled = skipRemaining <= 0 && !paused && !handoffVisible;
  const urgency = roundLeft <= 5;
  const difficulty = useMemo(() => {
    if (word.difficulty === 'veryHard') return { label: 'سخت', bonus: settings.hardWordBonuses ? '+۴ ثانیه' : null, color: theme.colors.primary };
    if (word.difficulty === 'hard') return { label: 'متوسط', bonus: settings.hardWordBonuses ? '+۲ ثانیه' : null, color: theme.colors.yellow };
    return { label: 'آسان', bonus: null, color: theme.colors.green };
  }, [settings.hardWordBonuses, word.difficulty]);

  const wordTranslate = wordIn.interpolate({ inputRange: [0, 1], outputRange: [18, 0] });
  const wordScale = wordIn.interpolate({ inputRange: [0, 1], outputRange: [0.97, 1] });
  const pulseScale = urgencyPulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] });
  const handoffScale = handoffAnim.interpolate({ inputRange: [0, 1], outputRange: [0.94, 1] });
  const circleSize = Math.min(screenWidth - 76, compact ? 270 : 302);
  const wordFont = wordType(word.text, compact);

  const advanceOverlay = () => {
    if (advancedOverlayRef.current) return;
    advancedOverlayRef.current = true; select(); nextRoundRef.current();
  };

  if (overlay) {
    let nextTeam = team;
    if (team.eliminated) {
      for (let offset = 1; offset <= teams.length; offset += 1) {
        const candidate = teams[(currentTeamIndex + offset) % teams.length];
        if (!candidate.eliminated) { nextTeam = candidate; break; }
      }
    }
    return (
      <Screen style={styles.overlayScreen} ambient={false}>
        <LinearGradient colors={['#FFF2C7','#FFF9E8',`${team.color}12`]} style={StyleSheet.absoluteFill} />
        <Pressable onPress={advanceOverlay} style={StyleSheet.absoluteFill}>
          <Animated.View style={[styles.burst,{ opacity:explosionFade,transform:[{scale:explosionScale}] }]}>{Array.from({length:16}).map((_,index)=><View key={index} style={[styles.burstRay,{backgroundColor:index%3===0?theme.colors.yellow:index%2===0?team.color:theme.colors.coral,transform:[{rotate:`${index*22.5}deg`},{translateY:-116}]}]}/>)}</Animated.View>
          <Animated.View style={[styles.overlayContent,{opacity:explosionFade,transform:[{scale:explosionScale}]}]}>
            <View style={[styles.boomOrb,{borderColor:team.color}]}><Text style={styles.boomEmoji}>{overlay.eliminated?'💥':'💣'}</Text></View>
            <Text style={styles.overlayBang}>{overlay.eliminated?'حذف شد!':'ترکید!'}</Text>
            <Text numberOfLines={2} style={[styles.overlayTeam,{color:team.color}]}>{team.title}</Text>
            <Text style={styles.overlayBody}>{overlay.body}</Text>
            <View style={styles.nextBlock}><Text style={styles.nextLabel}>{team.eliminated?'گوشی رو بده به':'راند بعد با'}</Text><View style={styles.nextTeamRow}><View style={[styles.nextDot,{backgroundColor:nextTeam.color}]}/><Text numberOfLines={2} style={[styles.nextTeam,{color:nextTeam.color}]}>{nextTeam.title}</Text></View></View>
          </Animated.View>
          <View style={styles.overlayFooter}><View style={styles.autoTrack}><Animated.View style={[styles.autoFill,{backgroundColor:team.color,transform:[{scaleX:overlayProgress}]}]}/></View><Text style={styles.overlayHint}>برای ادامه فوری لمس کن</Text></View>
        </Pressable>
      </Screen>
    );
  }

  return (
    <Screen style={styles.gameScreen} ambient={false}>
      <LinearGradient colors={['#FFF0C1','#FFF8E5','#FFF3D1']} style={StyleSheet.absoluteFill} />
      <View pointerEvents="none" style={styles.bgSun} />
      <View pointerEvents="none" style={styles.gameConfettiA} /><View pointerEvents="none" style={styles.gameConfettiB}/><View pointerEvents="none" style={styles.gameConfettiC}/>

      <View style={[styles.teamCards, teams.length > 3 && styles.teamCardsWrap]}>
        {teams.map((item,index) => {
          const active = item.id === team.id;
          const ratio = Math.max(0,Math.min(1,item.remaining/settings.reserveSeconds));
          return <View key={item.id} style={[styles.teamCard, teams.length > 3 && styles.teamCardHalf, active && {borderColor:item.color,transform:[{translateY:-3}]},item.eliminated&&{opacity:.35}]}>
            {active ? <Text style={styles.crown}>👑</Text> : null}
            <View style={styles.teamCardTop}><View style={[styles.teamFace,{backgroundColor:item.color}]}><Text style={styles.teamFaceText}>{teamFaces[index%teamFaces.length]}</Text></View><View style={styles.teamCardCopy}><Text numberOfLines={1} style={[styles.teamCardName,{color:active?item.color:theme.colors.textStrong}]}>{item.title}</Text><Text style={[styles.teamCardTime,{color:item.color}]}>{item.remaining.toLocaleString('fa-IR')} ثانیه</Text></View></View>
            <View style={styles.teamMiniTrack}><View style={[styles.teamMiniFill,{width:`${ratio*100}%`,backgroundColor:item.color}]}/></View>
          </View>;
        })}
      </View>

      <View style={styles.activeInfo}><Text style={[styles.activeTeamText,{color:team.color}]}>{team.title} · راند {roundNumber.toLocaleString('fa-IR')}</Text><Text style={styles.roleText}>{describer} توضیح می‌ده · {guesser} حدس می‌زنه</Text></View>

      <View style={styles.playStage}>
        <View pointerEvents="none" style={[styles.dottedOrbit,{width:circleSize+46,height:circleSize+46,borderRadius:(circleSize+46)/2}]}/>
        <Animated.View style={{transform:[{translateX:wordTranslate},{scale:Animated.multiply(wordScale,pulseScale)}],opacity:wordIn}}>
          <Pressable accessibilityRole="button" accessibilityLabel={`جواب درست: ${word.text}`} disabled={paused||handoffVisible} onPress={()=>runLockedAction(()=>{correct();onCorrect();})} style={({pressed})=>[styles.wordCircle,{width:circleSize,height:circleSize,borderRadius:circleSize/2,borderColor:'#F0B72F'},pressed&&styles.wordCirclePressed]}>
            <LinearGradient colors={['#FFFDF7','#FFF4D9']} style={[StyleSheet.absoluteFill,{borderRadius:circleSize/2}]}/>
            <View style={styles.clockPill}><Text style={styles.clockEmoji}>⏱</Text>{urgency?<Text style={[styles.clockUrgent,{color:theme.colors.danger}]}>{Math.max(0,Math.ceil(roundLeft)).toLocaleString('fa-IR')}</Text>:hiddenClock?<Text style={styles.clockSmall}>بمب مخفی</Text>:<Text style={styles.clockSmall}>{Math.max(0,Math.ceil(roundLeft)).toLocaleString('fa-IR')} ثانیه</Text>}</View>
            <View style={styles.wordArea}><Text maxFontSizeMultiplier={1} style={[styles.word,wordFont]}>{word.text}</Text></View>
            <View style={styles.circleMeta}><View style={[styles.diffPill,{backgroundColor:`${difficulty.color}12`,borderColor:`${difficulty.color}50`}]}><View style={[styles.diffDot,{backgroundColor:difficulty.color}]}/><Text style={[styles.diffText,{color:difficulty.color}]}>{difficulty.label}</Text></View>{difficulty.bonus?<View style={styles.bonusPill}><Text style={styles.bonusText}>{difficulty.bonus}</Text></View>:<View/>}</View>
          </Pressable>
        </Animated.View>
        {teams.slice(0,6).map((item,index)=>{
          const positions=[styles.avatarTop,styles.avatarUpperRight,styles.avatarLowerRight,styles.avatarBottom,styles.avatarLowerLeft,styles.avatarUpperLeft];
          return <View key={item.id} pointerEvents="none" style={[styles.avatarOrb,positions[index],{backgroundColor:item.color}]}><Text style={styles.avatarFace}>{teamFaces[index%teamFaces.length]}</Text></View>;
        })}
      </View>

      <View style={styles.hintCard}><Text style={styles.hintEmoji}>☝️</Text><Text style={styles.correctHint}>حدس زد؟ فقط دایره دور کلمه رو لمس کن</Text></View>

      <View style={styles.actionRow}>
        <Pressable disabled={!skipEnabled} onPress={()=>runLockedAction(()=>{skip();onSkip();})} style={({pressed})=>[styles.actionCard,styles.skipCard,!skipEnabled&&styles.actionDisabled,pressed&&skipEnabled&&styles.pressed]}><View style={styles.actionIcon}><Text style={styles.actionIconText}>⏭</Text></View><View style={styles.actionCopy}><Text style={styles.actionTitle}>{skipEnabled?'رد کردن':`${Math.ceil(skipRemaining).toLocaleString('fa-IR')} ثانیه تا رد`}</Text><Text style={styles.actionSub}>{skipEnabled?'کلمه بعدی':'چند ثانیه اول قفله'}</Text></View></Pressable>
        <Pressable onPress={pauseGame} style={({pressed})=>[styles.actionCard,styles.stopCard,pressed&&styles.pressed]}><View style={[styles.actionIcon,{backgroundColor:'rgba(255,255,255,.24)'}]}><Text style={styles.actionIconText}>■</Text></View><View style={styles.actionCopy}><Text style={[styles.actionTitle,{color:'#fff'}]}>پایان دور</Text><Text style={[styles.actionSub,{color:'rgba(255,255,255,.82)'}]}>توقف بازی</Text></View></Pressable>
      </View>
      <View style={styles.footerPill}><Text style={styles.footerText}>{teams.length.toLocaleString('fa-IR')} تیم  •  یک گوشی  •  {settings.hardWordBonuses?'بونس روشن':'بدون بونس'}</Text></View>

      {handoffVisible ? <Animated.View pointerEvents="auto" style={[styles.handoff,{opacity:handoffAnim,transform:[{scale:handoffScale}]}]}><LinearGradient colors={['#FFF1C7','#FFF9EB']} style={StyleSheet.absoluteFill}/><View style={[styles.handoffOrb,{backgroundColor:`${team.color}1C`,borderColor:team.color}]}><Text style={styles.handoffFace}>{teamFaces[currentTeamIndex%teamFaces.length]}</Text></View><Text style={styles.handoffLabel}>گوشی رو بده به</Text><Text numberOfLines={2} style={[styles.handoffTeam,{color:team.color}]}>{team.title}</Text></Animated.View> : null}

      {paused ? <View style={styles.pauseScrim}><View style={styles.pauseCard}><View style={styles.pauseIcon}><Text style={styles.pauseEmoji}>⏸️</Text></View><Text style={styles.pauseTitle}>مکث</Text><Text style={styles.pauseBody}>تایمر و رد کردن فریز شدن.</Text><Pressable onPress={resumeGame} style={({pressed})=>[styles.resume,pressed&&styles.pressed]}><LinearGradient colors={['#8F68FF','#6A38F5']} style={styles.resumeGradient}><Text style={styles.resumeText}>ادامه</Text></LinearGradient></Pressable><Pressable onPress={onQuit} style={({pressed})=>[styles.quit,pressed&&styles.pressed]}><Text style={styles.quitText}>خروج از بازی</Text></Pressable></View></View> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  gameScreen:{paddingHorizontal:13,paddingTop:4,paddingBottom:8},pressed:{opacity:.83,transform:[{scale:.985}]},bgSun:{position:'absolute',width:510,height:510,borderRadius:255,backgroundColor:'rgba(255,204,57,.09)',top:125,left:'50%',marginLeft:-255},gameConfettiA:{position:'absolute',width:12,height:6,borderRadius:4,backgroundColor:theme.colors.primary,top:'17%',left:'7%',transform:[{rotate:'18deg'}]},gameConfettiB:{position:'absolute',width:12,height:6,borderRadius:4,backgroundColor:theme.colors.cyan,top:'44%',right:'5%',transform:[{rotate:'-28deg'}]},gameConfettiC:{position:'absolute',width:12,height:6,borderRadius:4,backgroundColor:theme.colors.green,bottom:'21%',left:'11%',transform:[{rotate:'35deg'}]},
  teamCards:{flexDirection:'row-reverse',gap:7,justifyContent:'center'},teamCardsWrap:{flexWrap:'wrap'},teamCard:{flex:1,minWidth:0,minHeight:66,borderRadius:20,backgroundColor:'#FFFDF8',borderWidth:1.5,borderColor:theme.colors.border,paddingHorizontal:7,paddingVertical:6,shadowColor:'#C68A53',shadowOpacity:.08,shadowRadius:7,shadowOffset:{width:0,height:4}},teamCardHalf:{flexBasis:'31%',maxWidth:'32%'},crown:{position:'absolute',top:-16,alignSelf:'center',fontSize:20,zIndex:4},teamCardTop:{flexDirection:'row-reverse',alignItems:'center',gap:6},teamFace:{width:32,height:32,borderRadius:16,borderWidth:3,borderColor:'#fff',alignItems:'center',justifyContent:'center'},teamFaceText:{fontSize:17},teamCardCopy:{flex:1,minWidth:0,alignItems:'flex-end'},teamCardName:{fontFamily:theme.fonts.black,fontSize:9.2,lineHeight:18,writingDirection:'rtl',textAlign:'right'},teamCardTime:{fontFamily:theme.fonts.bold,fontSize:7.5,lineHeight:15,writingDirection:'rtl'},teamMiniTrack:{height:5,borderRadius:3,backgroundColor:'#EEE3D9',overflow:'hidden',marginTop:4},teamMiniFill:{height:5,borderRadius:3},
  activeInfo:{alignItems:'center',paddingTop:7,paddingBottom:1},activeTeamText:{fontFamily:theme.fonts.black,fontSize:10.5,lineHeight:21,writingDirection:'rtl'},roleText:{color:theme.colors.muted,fontFamily:theme.fonts.medium,fontSize:8.4,lineHeight:17,writingDirection:'rtl',marginTop:1},
  playStage:{flex:1,minHeight:318,alignItems:'center',justifyContent:'center'},dottedOrbit:{position:'absolute',borderWidth:1.5,borderColor:'rgba(240,183,47,.55)',borderStyle:'dashed'},wordCircle:{borderWidth:4.5,alignItems:'center',justifyContent:'space-between',paddingTop:24,paddingBottom:19,paddingHorizontal:24,shadowColor:'#D39A34',shadowOpacity:.15,shadowRadius:15,shadowOffset:{width:0,height:8},elevation:4},wordCirclePressed:{opacity:.88,transform:[{scale:.982}]},clockPill:{minHeight:38,borderRadius:19,backgroundColor:'#FFFDF8',paddingHorizontal:12,flexDirection:'row-reverse',alignItems:'center',justifyContent:'center',gap:5,borderWidth:1,borderColor:theme.colors.border,shadowColor:'#B67F55',shadowOpacity:.06,shadowRadius:5,shadowOffset:{width:0,height:3}},clockEmoji:{fontSize:15},clockSmall:{color:theme.colors.textStrong,fontFamily:theme.fonts.black,fontSize:10.5,lineHeight:21,writingDirection:'rtl'},clockUrgent:{fontFamily:theme.fonts.black,fontSize:19,lineHeight:29},wordArea:{flex:1,width:'100%',minHeight:105,alignItems:'center',justifyContent:'center',paddingHorizontal:2,paddingVertical:10},word:{width:'100%',color:theme.colors.textStrong,fontFamily:theme.fonts.black,textAlign:'center',writingDirection:'rtl',paddingVertical:13,letterSpacing:-.5},circleMeta:{width:'100%',flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between'},diffPill:{minHeight:31,borderRadius:16,borderWidth:1.4,flexDirection:'row-reverse',alignItems:'center',gap:5,paddingHorizontal:9},diffDot:{width:7,height:7,borderRadius:4},diffText:{fontFamily:theme.fonts.black,fontSize:8.8,lineHeight:18,writingDirection:'rtl'},bonusPill:{minHeight:31,borderRadius:16,backgroundColor:'#FFF2D0',borderWidth:1,borderColor:'rgba(255,180,45,.35)',paddingHorizontal:9,alignItems:'center',justifyContent:'center'},bonusText:{color:'#D99200',fontFamily:theme.fonts.black,fontSize:8.7,lineHeight:17,writingDirection:'rtl'},
  avatarOrb:{position:'absolute',width:45,height:45,borderRadius:23,borderWidth:4,borderColor:'#fff',alignItems:'center',justifyContent:'center',shadowColor:'#8B6348',shadowOpacity:.12,shadowRadius:6,shadowOffset:{width:0,height:4},elevation:3},avatarFace:{fontSize:24},avatarTop:{top:4,left:'50%',marginLeft:-23},avatarUpperRight:{right:2,top:'28%'},avatarLowerRight:{right:18,bottom:40},avatarBottom:{bottom:2,left:'50%',marginLeft:-23},avatarLowerLeft:{left:18,bottom:40},avatarUpperLeft:{left:2,top:'28%'},
  hintCard:{minHeight:48,borderRadius:24,backgroundColor:'#FFFDF8',borderWidth:1.6,borderColor:'#FFD0C5',paddingHorizontal:14,flexDirection:'row-reverse',alignItems:'center',justifyContent:'center',gap:8,marginTop:1,shadowColor:'#B67F55',shadowOpacity:.06,shadowRadius:7,shadowOffset:{width:0,height:4}},hintEmoji:{fontSize:20},correctHint:{color:theme.colors.textStrong,fontFamily:theme.fonts.bold,fontSize:10.4,lineHeight:22,textAlign:'center',writingDirection:'rtl'},
  actionRow:{flexDirection:'row-reverse',gap:9,minHeight:64,marginTop:7},actionCard:{flex:1,borderRadius:25,minHeight:61,flexDirection:'row-reverse',alignItems:'center',justifyContent:'center',gap:8,paddingHorizontal:10,borderWidth:3,shadowOpacity:.14,shadowRadius:9,shadowOffset:{width:0,height:5}},skipCard:{backgroundColor:'#FFC543',borderColor:'#FFF2BD',shadowColor:'#C99222'},stopCard:{backgroundColor:theme.colors.primaryStrong,borderColor:'#FFE6EC',shadowColor:theme.colors.primaryStrong},actionDisabled:{opacity:.55},actionIcon:{width:39,height:39,borderRadius:20,backgroundColor:'rgba(255,255,255,.35)',alignItems:'center',justifyContent:'center'},actionIconText:{color:'#fff',fontSize:19},actionCopy:{alignItems:'flex-end'},actionTitle:{color:theme.colors.textStrong,fontFamily:theme.fonts.black,fontSize:12.5,lineHeight:24,writingDirection:'rtl'},actionSub:{color:'#8A6732',fontFamily:theme.fonts.medium,fontSize:7.8,lineHeight:15,writingDirection:'rtl'},footerPill:{alignSelf:'center',minHeight:30,borderRadius:15,backgroundColor:'rgba(255,255,255,.72)',borderWidth:1,borderColor:theme.colors.border,paddingHorizontal:12,alignItems:'center',justifyContent:'center',marginTop:5},footerText:{color:theme.colors.muted,fontFamily:theme.fonts.medium,fontSize:7.9,lineHeight:16,writingDirection:'rtl'},
  handoff:{position:'absolute',top:0,right:0,bottom:0,left:0,zIndex:12,alignItems:'center',justifyContent:'center'},handoffOrb:{width:118,height:118,borderRadius:59,borderWidth:3,alignItems:'center',justifyContent:'center',marginBottom:12},handoffFace:{fontSize:62},handoffLabel:{color:theme.colors.text,fontFamily:theme.fonts.bold,fontSize:13,lineHeight:26,writingDirection:'rtl'},handoffTeam:{maxWidth:'84%',fontFamily:theme.fonts.black,fontSize:35,lineHeight:59,textAlign:'center',writingDirection:'rtl',paddingVertical:4},
  pauseScrim:{position:'absolute',top:0,right:0,bottom:0,left:0,zIndex:20,backgroundColor:'rgba(91,48,23,.24)',alignItems:'center',justifyContent:'center',paddingHorizontal:24},pauseCard:{width:'100%',maxWidth:390,borderRadius:34,backgroundColor:'#FFFDF8',borderWidth:2,borderColor:theme.colors.border,padding:22,alignItems:'center',shadowColor:'#9C6C49',shadowOpacity:.18,shadowRadius:22,shadowOffset:{width:0,height:12}},pauseIcon:{width:72,height:72,borderRadius:36,backgroundColor:'#F0E8FF',alignItems:'center',justifyContent:'center',marginBottom:8},pauseEmoji:{fontSize:38},pauseTitle:{color:theme.colors.coral,fontFamily:theme.fonts.black,fontSize:32,lineHeight:54,writingDirection:'rtl'},pauseBody:{color:theme.colors.text,fontFamily:theme.fonts.medium,fontSize:11.5,lineHeight:24,textAlign:'center',writingDirection:'rtl'},resume:{width:'100%',minHeight:58,borderRadius:28,overflow:'hidden',marginTop:15},resumeGradient:{flex:1,minHeight:58,alignItems:'center',justifyContent:'center'},resumeText:{color:'#fff',fontFamily:theme.fonts.black,fontSize:16,lineHeight:31,writingDirection:'rtl'},quit:{minHeight:44,alignItems:'center',justifyContent:'center',marginTop:7,paddingHorizontal:14},quitText:{color:theme.colors.muted,fontFamily:theme.fonts.bold,fontSize:10.5,lineHeight:21,writingDirection:'rtl'},
  overlayScreen:{alignItems:'center',justifyContent:'center',paddingHorizontal:22},burst:{position:'absolute',width:295,height:295,alignSelf:'center',top:'31%',left:'50%',marginLeft:-147},burstRay:{position:'absolute',left:144,top:144,width:7,height:64,borderRadius:4},overlayContent:{alignItems:'center',maxWidth:390,paddingHorizontal:8},boomOrb:{width:116,height:116,borderRadius:58,borderWidth:4,backgroundColor:'#FFFDF8',alignItems:'center',justifyContent:'center',marginBottom:7},boomEmoji:{fontSize:60},overlayBang:{color:theme.colors.coral,fontFamily:theme.fonts.black,fontSize:49,lineHeight:80,textAlign:'center',writingDirection:'rtl',paddingVertical:3},overlayTeam:{maxWidth:'94%',fontFamily:theme.fonts.black,fontSize:35,lineHeight:58,textAlign:'center',writingDirection:'rtl',paddingVertical:3},overlayBody:{maxWidth:'92%',color:theme.colors.textStrong,fontFamily:theme.fonts.medium,fontSize:11.5,lineHeight:24,textAlign:'center',writingDirection:'rtl',paddingVertical:3},nextBlock:{marginTop:16,alignItems:'center'},nextLabel:{color:theme.colors.muted,fontFamily:theme.fonts.bold,fontSize:10,lineHeight:20,writingDirection:'rtl'},nextTeamRow:{flexDirection:'row-reverse',alignItems:'center',gap:7,marginTop:3},nextDot:{width:10,height:10,borderRadius:5},nextTeam:{maxWidth:250,fontFamily:theme.fonts.black,fontSize:18,lineHeight:31,writingDirection:'rtl',textAlign:'center'},overlayFooter:{position:'absolute',bottom:32,left:40,right:40,alignItems:'center',gap:8},autoTrack:{width:190,height:6,borderRadius:3,backgroundColor:'#E3D3C5',overflow:'hidden'},autoFill:{width:'100%',height:6,borderRadius:3},overlayHint:{color:theme.colors.muted,fontFamily:theme.fonts.medium,fontSize:9.5,lineHeight:19,writingDirection:'rtl'},
});
