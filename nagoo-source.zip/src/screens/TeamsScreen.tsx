import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { PrimaryButton, Screen, SectionTitle, TopNav } from '../components/UI';
import { theme } from '../theme';
import { TeamDraft } from '../types';

const faces = ['😄', '😉', '😋', '😎', '🤩', '🥳'];
const mateFaces = ['🙂', '😁', '😊', '🤗', '😜', '😇'];

export function TeamsScreen({ teams, onChangeCount, onChangeTeam, onBack, onNext }: {
  teams: TeamDraft[]; onChangeCount: (count: number) => void; onChangeTeam: (index: number, patch: Partial<TeamDraft>) => void; onBack: () => void; onNext: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [selected, setSelected] = useState(0);
  const team = teams[Math.min(selected, teams.length - 1)];

  return (
    <Screen style={styles.screen}>
      <TopNav onBack={onBack} />
      <SectionTitle center title="چند تیم بازی می‌کنن؟" subtitle="هر تیم دو نفره‌ست. اسم‌گذاری کاملاً اختیاریه؛ می‌تونی همین الان ادامه بدی." />

      <View style={styles.countShell}>
        {[2,3,4,5,6].map((count) => {
          const active = teams.length === count;
          return <Pressable key={count} onPress={() => { onChangeCount(count); setSelected(v => Math.min(v, count - 1)); }} style={({ pressed }) => [styles.count, active && styles.countActive, pressed && styles.pressed]}><Text style={[styles.countNumber, active && styles.countNumberActive]}>{count.toLocaleString('fa-IR')}</Text><Text style={[styles.countLabel, active && styles.countLabelActive]}>تیم</Text></Pressable>;
        })}
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          <View style={styles.teamGrid}>
            {teams.map((item, index) => {
              const active = selected === index;
              const personalized = !!(item.player1 || item.player2);
              return (
                <Pressable key={item.id} onPress={() => { setSelected(index); setEditing(false); }} style={({ pressed }) => [styles.teamCard, { backgroundColor: item.color, borderColor: active ? '#FFFDF8' : `${item.color}55` }, active && styles.teamCardActive, pressed && styles.pressed]}>
                  <Text style={styles.teamName}>{item.title || `تیم ${index + 1}`}</Text>
                  <View style={styles.facesRow}><View style={styles.faceBubble}><Text style={styles.faceText}>{faces[index % faces.length]}</Text></View><View style={[styles.faceBubble, styles.faceOverlap]}><Text style={styles.faceText}>{mateFaces[index % mateFaces.length]}</Text></View></View>
                  <View style={styles.readyPill}><Text style={[styles.readyText, { color: item.color }]}>{personalized ? 'شخصی‌سازی شده ✓' : 'آماده ✓'}</Text></View>
                </Pressable>
              );
            })}
          </View>

          <View style={[styles.selectedPanel, { borderColor: `${team.color}72` }]}> 
            <View style={[styles.selectedTitlePill, { backgroundColor: team.color }]}><Text style={styles.selectedTitle}>{team.title || `تیم ${selected + 1}`}</Text></View>
            {!editing ? <>
              <View style={styles.members}>
                <View style={styles.member}><View style={[styles.memberAvatar, { backgroundColor: team.color }]}><Text style={styles.memberEmoji}>{faces[selected % faces.length]}</Text></View><View style={styles.memberNamePill}><Text numberOfLines={2} style={styles.memberName}>{team.player1 || 'نفر اول'}</Text></View></View>
                <View style={styles.heart}><Text style={styles.heartText}>♥</Text></View>
                <View style={styles.member}><View style={[styles.memberAvatar, { backgroundColor: '#FFC542' }]}><Text style={styles.memberEmoji}>{mateFaces[selected % mateFaces.length]}</Text></View><View style={styles.memberNamePill}><Text numberOfLines={2} style={styles.memberName}>{team.player2 || 'نفر دوم'}</Text></View></View>
              </View>
              <View style={styles.divider} />
              <Pressable onPress={() => setEditing(true)} style={({ pressed }) => [styles.editLink, pressed && styles.pressed]}><Text style={styles.editLinkText}>✎ می‌خوام اسم‌ها رو عوض کنم</Text></Pressable>
            </> : <View style={styles.editor}>
              <TextInput value={team.title} onChangeText={(title) => onChangeTeam(selected, { title })} placeholder={`تیم ${selected + 1}`} placeholderTextColor={theme.colors.muted2} selectionColor={team.color} style={styles.teamNameInput} textAlign="right" maxFontSizeMultiplier={1} />
              <View style={styles.playersRow}><View style={styles.playerField}><Text style={styles.fieldLabel}>نفر اول</Text><TextInput value={team.player1} onChangeText={(player1) => onChangeTeam(selected, { player1 })} placeholder="اسم" placeholderTextColor={theme.colors.muted2} selectionColor={team.color} style={styles.playerInput} textAlign="right" maxFontSizeMultiplier={1} /></View><View style={styles.playerField}><Text style={styles.fieldLabel}>نفر دوم</Text><TextInput value={team.player2} onChangeText={(player2) => onChangeTeam(selected, { player2 })} placeholder="اسم" placeholderTextColor={theme.colors.muted2} selectionColor={team.color} style={styles.playerInput} textAlign="right" maxFontSizeMultiplier={1} /></View></View>
              <Pressable onPress={() => setEditing(false)} style={({ pressed }) => [styles.doneEdit, { backgroundColor: team.color }, pressed && styles.pressed]}><Text style={styles.doneEditText}>تمام</Text></Pressable>
            </View>}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <PrimaryButton label="ادامه" onPress={onNext} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingBottom: 12 }, flex: { flex: 1 }, pressed: { opacity: .84, transform: [{ scale: .984 }] },
  countShell: { minHeight: 74, flexDirection: 'row-reverse', gap: 6, padding: 7, borderRadius: 34, backgroundColor: '#FFFDF8', borderWidth: 1.5, borderColor: theme.colors.border, shadowColor: '#C68A53', shadowOpacity: .09, shadowRadius: 11, shadowOffset: { width: 0, height: 6 } },
  count: { flex: 1, minWidth: 0, minHeight: 58, borderRadius: 28, alignItems: 'center', justifyContent: 'center', paddingVertical: 2 }, countActive: { backgroundColor: theme.colors.primaryStrong, borderWidth: 4, borderColor: '#FFFDF8', shadowColor: theme.colors.primaryStrong, shadowOpacity: .25, shadowRadius: 10, shadowOffset: { width: 0, height: 5 } }, countNumber: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 18, lineHeight: 29 }, countNumberActive: { color: '#fff' }, countLabel: { color: theme.colors.text, fontFamily: theme.fonts.bold, fontSize: 9.3, lineHeight: 18 }, countLabelActive: { color: '#fff' },
  scroll: { paddingTop: 15, paddingBottom: 17 }, teamGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', justifyContent: 'center', gap: 10, paddingHorizontal: 1 },
  teamCard: { width: '31.3%', minHeight: 139, borderRadius: 24, borderWidth: 3, paddingHorizontal: 8, paddingVertical: 10, alignItems: 'center', justifyContent: 'space-between', shadowColor: '#87572F', shadowOpacity: .15, shadowRadius: 11, shadowOffset: { width: 0, height: 6 }, elevation: 4 }, teamCardActive: { transform: [{ translateY: -4 }], shadowOpacity: .23 },
  teamName: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 14.5, lineHeight: 29, textAlign: 'center', writingDirection: 'rtl', paddingVertical: 1 }, facesRow: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center' }, faceBubble: { width: 45, height: 45, borderRadius: 23, backgroundColor: 'rgba(255,255,255,.27)', borderWidth: 2, borderColor: 'rgba(255,255,255,.62)', alignItems: 'center', justifyContent: 'center' }, faceOverlap: { marginRight: -10 }, faceText: { fontSize: 25 }, readyPill: { minHeight: 31, borderRadius: 17, backgroundColor: 'rgba(255,255,255,.90)', minWidth: '92%', paddingHorizontal: 5, alignItems: 'center', justifyContent: 'center' }, readyText: { fontFamily: theme.fonts.black, fontSize: 7.8, lineHeight: 16, writingDirection: 'rtl', textAlign: 'center' },
  selectedPanel: { marginTop: 20, borderRadius: 31, borderWidth: 2.5, padding: 16, paddingTop: 36, alignItems: 'center', minHeight: 220, backgroundColor: 'rgba(255,253,248,.91)', shadowColor: '#C68A53', shadowOpacity: .11, shadowRadius: 13, shadowOffset: { width: 0, height: 7 } }, selectedTitlePill: { position: 'absolute', top: -18, minHeight: 44, borderRadius: 22, paddingHorizontal: 34, alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: '#FFF3CF' }, selectedTitle: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 18, lineHeight: 34, writingDirection: 'rtl' },
  members: { width: '100%', flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-around', gap: 8, marginTop: 4 }, member: { width: '38%', alignItems: 'center' }, memberAvatar: { width: 66, height: 66, borderRadius: 33, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#82522D', shadowOpacity: .12, shadowRadius: 8, shadowOffset: { width: 0, height: 5 }, zIndex: 2 }, memberEmoji: { fontSize: 35 }, memberNamePill: { width: '100%', minHeight: 45, marginTop: -7, paddingTop: 9, borderRadius: 22, backgroundColor: '#fff', borderWidth: 1.2, borderColor: theme.colors.border, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 }, memberName: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 13, lineHeight: 27, writingDirection: 'rtl', textAlign: 'center' }, heart: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#FFF0ED', alignItems: 'center', justifyContent: 'center' }, heartText: { color: theme.colors.primaryStrong, fontSize: 22 }, divider: { width: '100%', height: 1, backgroundColor: '#F0D8CB', marginTop: 13, marginBottom: 5 }, editLink: { minHeight: 38, justifyContent: 'center', paddingHorizontal: 10 }, editLinkText: { color: theme.colors.primaryStrong, fontFamily: theme.fonts.bold, fontSize: 10.5, lineHeight: 22, writingDirection: 'rtl' },
  editor: { width: '100%', gap: 10 }, teamNameInput: { minHeight: 49, borderRadius: 22, backgroundColor: '#fff', borderWidth: 1.4, borderColor: theme.colors.border, color: theme.colors.textStrong, fontFamily: theme.fonts.bold, fontSize: 14, lineHeight: 26, paddingHorizontal: 15, paddingVertical: 8 }, playersRow: { flexDirection: 'row-reverse', gap: 9 }, playerField: { flex: 1 }, fieldLabel: { color: theme.colors.muted, fontFamily: theme.fonts.bold, fontSize: 9, lineHeight: 19, textAlign: 'right', writingDirection: 'rtl', marginBottom: 3 }, playerInput: { minHeight: 47, borderRadius: 21, backgroundColor: '#fff', borderWidth: 1.4, borderColor: theme.colors.border, color: theme.colors.textStrong, fontFamily: theme.fonts.bold, fontSize: 13, lineHeight: 25, paddingHorizontal: 13, paddingVertical: 8 }, doneEdit: { minHeight: 47, borderRadius: 23, alignItems: 'center', justifyContent: 'center' }, doneEditText: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 13, lineHeight: 26 },
});
