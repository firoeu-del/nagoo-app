import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { PrimaryButton, Screen, SectionTitle, TopNav } from '../components/UI';
import { difficultyMeta } from '../data/categoryMeta';
import { theme } from '../theme';
import { CustomWord, WordDifficulty } from '../types';

const levels: WordDifficulty[] = ['normal', 'hard', 'veryHard'];

export function CustomWordsScreen({ words, onChange, onBack }: { words: CustomWord[]; onChange: (words: CustomWord[]) => void; onBack: () => void }) {
  const [text, setText] = useState('');
  const [difficulty, setDifficulty] = useState<WordDifficulty>('normal');
  const add = () => {
    const clean = text.trim();
    if (!clean || words.some((item) => item.text.trim() === clean)) return;
    onChange([{ id: `custom-${Date.now()}`, text: clean, difficulty }, ...words]);
    setText(''); setDifficulty('normal');
  };

  return (
    <Screen>
      <TopNav onBack={onBack} />
      <SectionTitle center title="پک خودمون" subtitle="اسم دوست‌ها، اصطلاحات جمع و چیزهایی که فقط خودتون می‌فهمید." />
      <View style={styles.composer}>
        <View style={styles.emojiCircle}><Text style={styles.emoji}>✍️</Text></View>
        <TextInput value={text} onChangeText={setText} onSubmitEditing={add} returnKeyType="done" placeholder="کلمه رو بنویس…" placeholderTextColor={theme.colors.muted2} selectionColor={theme.colors.violet} maxFontSizeMultiplier={1} style={styles.input} textAlign="right" />
        <View style={styles.levels}>
          {levels.map((level) => {
            const active = difficulty === level;
            return <Pressable key={level} onPress={() => setDifficulty(level)} style={[styles.level, active && { borderColor: difficultyMeta[level].color, backgroundColor: '#fff' }]}><View style={[styles.levelDot, { backgroundColor: active ? difficultyMeta[level].color : '#D1C3B9' }]} /><Text maxFontSizeMultiplier={1} style={[styles.levelText, { color: active ? difficultyMeta[level].color : theme.colors.muted }]}>{difficultyMeta[level].label}</Text></Pressable>;
          })}
        </View>
        <PrimaryButton label="اضافه کن" onPress={add} disabled={!text.trim()} compact icon="+" />
      </View>

      <View style={styles.listHead}><Text maxFontSizeMultiplier={1} style={styles.listTitle}>داخل پک</Text><Text maxFontSizeMultiplier={1} style={styles.listCount}>{words.length.toLocaleString('fa-IR')} کلمه</Text></View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.list}>
        {words.length === 0 ? <View style={styles.empty}><View style={styles.emptyCircle}><Text style={styles.emptyPlus}>+</Text></View><Text maxFontSizeMultiplier={1} style={styles.emptyText}>اولین کلمه‌ی مخصوص جمع رو اضافه کن.</Text></View> : words.map((item) => (
          <View key={item.id} style={styles.row}>
            <Pressable onPress={() => onChange(words.filter((word) => word.id !== item.id))} style={styles.delete}><Text style={styles.deleteText}>×</Text></Pressable>
            <View style={styles.wordCopy}><Text numberOfLines={4} maxFontSizeMultiplier={1} style={styles.word}>{item.text}</Text><View style={styles.diffRow}><View style={[styles.diffDot, { backgroundColor: difficultyMeta[item.difficulty].color }]} /><Text maxFontSizeMultiplier={1} style={styles.diff}>{difficultyMeta[item.difficulty].label}</Text></View></View>
          </View>
        ))}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  composer: { borderRadius: 31, backgroundColor: 'rgba(255,255,255,0.84)', borderWidth: 1.5, borderColor: theme.colors.border, padding: 14, shadowColor: theme.shadow.color, shadowOpacity: 0.1, shadowRadius: 12, shadowOffset: { width: 0, height: 7 }, alignItems: 'center' }, emojiCircle: { width: 64, height: 64, borderRadius: 32, backgroundColor: '#E9F8FF', borderWidth: 3, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 9 }, emoji: { fontSize: 34 },
  input: { width: '100%', minHeight: 70, color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 23, lineHeight: 44, writingDirection: 'rtl', includeFontPadding: true, paddingHorizontal: 14, paddingVertical: 10, backgroundColor: '#FFF9ED', borderRadius: 24, borderWidth: 1.5, borderColor: theme.colors.border },
  levels: { width: '100%', flexDirection: 'row-reverse', gap: 8, marginVertical: 11 }, level: { flex: 1, minHeight: 47, borderRadius: 22, borderWidth: 1.5, borderColor: theme.colors.border, backgroundColor: '#FFF9ED', flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6 }, levelDot: { width: 8, height: 8, borderRadius: 4 }, levelText: { fontFamily: theme.fonts.black, fontSize: 9.7, lineHeight: 19, writingDirection: 'rtl', includeFontPadding: true },
  listHead: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginTop: 20, marginBottom: 6 }, listTitle: { color: theme.colors.coral, fontFamily: theme.fonts.black, fontSize: 15, lineHeight: 29, writingDirection: 'rtl', includeFontPadding: true }, listCount: { color: theme.colors.text, fontFamily: theme.fonts.bold, fontSize: 9.5, lineHeight: 19, writingDirection: 'rtl', includeFontPadding: true },
  list: { paddingBottom: 16 }, row: { minHeight: 76, flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.75)', borderWidth: 1, borderColor: theme.colors.border, paddingVertical: 8, paddingHorizontal: 10, marginBottom: 7 }, delete: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#FFF0F2', borderWidth: 1, borderColor: 'rgba(244,63,94,0.18)', alignItems: 'center', justifyContent: 'center' }, deleteText: { color: theme.colors.danger, fontFamily: theme.fonts.black, fontSize: 22, lineHeight: 27 }, wordCopy: { flex: 1, minWidth: 0, alignItems: 'flex-end' }, word: { maxWidth: '100%', color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 14.5, lineHeight: 30, textAlign: 'right', writingDirection: 'rtl', includeFontPadding: true, paddingVertical: 3 }, diffRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, marginTop: 2 }, diffDot: { width: 6, height: 6, borderRadius: 3 }, diff: { color: theme.colors.muted, fontFamily: theme.fonts.bold, fontSize: 8.5, lineHeight: 17, writingDirection: 'rtl' },
  empty: { minHeight: 180, alignItems: 'center', justifyContent: 'center' }, emptyCircle: { width: 64, height: 64, borderRadius: 32, borderWidth: 2, borderColor: 'rgba(53,189,241,0.35)', backgroundColor: '#EAF9FF', alignItems: 'center', justifyContent: 'center' }, emptyPlus: { color: theme.colors.cyan, fontFamily: theme.fonts.black, fontSize: 28 }, emptyText: { color: theme.colors.text, fontFamily: theme.fonts.medium, fontSize: 10.5, lineHeight: 22, textAlign: 'center', writingDirection: 'rtl', includeFontPadding: true, marginTop: 10 },
});
