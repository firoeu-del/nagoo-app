import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { finalStandings } from '../game/engine';
import { useGameFeedback } from '../hooks/useGameFeedback';
import { teamPalette, theme } from '../theme';
import { TeamState } from '../types';

const confetti = Array.from({ length: 18 }, (_, i) => ({
  top: `${6 + (i * 5.1) % 72}%`, left: `${4 + (i * 17) % 90}%`, rotate: `${(i * 31) % 180}deg`, color: i % teamPalette.length,
}));
const faces = ['😄','😉','😋','😎','🤩','🥳'];

export function ResultsScreen({ winner, teams, onRematch, onEditTeams, soundEnabled, hapticsEnabled }: {
  winner: TeamState; teams: TeamState[]; onRematch: () => void; onEditTeams: () => void; soundEnabled: boolean; hapticsEnabled: boolean;
}) {
  const { win, select } = useGameFeedback(soundEnabled, hapticsEnabled);
  const enter = useRef(new Animated.Value(0)).current;
  const [detailsOpen, setDetailsOpen] = useState(false);
  const ordered = useMemo(() => finalStandings(teams), [teams]);
  const winnerIndex = Math.max(0, teams.findIndex(t => t.id === winner.id));

  useEffect(() => { win(); Animated.spring(enter, { toValue: 1, tension: 52, friction: 8, useNativeDriver: true }).start(); }, [enter, win]);
  const heroScale = enter.interpolate({ inputRange: [0,1], outputRange: [.9,1] });
  const players = [winner.player1 || 'نفر اول', winner.player2 || 'نفر دوم'];

  return (
    <SafeAreaView style={styles.safe}>
      <LinearGradient colors={['#FFF0C2','#FFF8E6','#FFF2CD']} style={StyleSheet.absoluteFill} />
      <View style={styles.sun} />
      {confetti.map((p,i) => <Animated.View key={i} style={[styles.confetti,{ top:p.top as any,left:p.left as any,backgroundColor:teamPalette[p.color],opacity:enter,transform:[{rotate:p.rotate},{scale:enter}]}]} />)}
      <Animated.View style={[styles.hero,{ opacity:enter, transform:[{scale:heroScale}] }]}>
        <Text style={styles.winWord}>بردید!</Text>
        <View style={styles.trophyWrap}>
          <LinearGradient colors={['#FF7B55','#FFCC3D']} style={styles.trophyDisc}><Text style={styles.trophyEmoji}>👑</Text></LinearGradient>
          <View style={[styles.ribbon,{ backgroundColor:winner.color }]}><Text numberOfLines={2} style={styles.ribbonText}>{winner.title}</Text></View>
        </View>
        <View style={styles.playersRow}>
          <View style={styles.player}><View style={[styles.playerAvatar,{ backgroundColor:'#FFCB51' }]}><Text style={styles.playerFace}>{faces[(winnerIndex+1)%faces.length]}</Text></View><Text numberOfLines={1} style={styles.playerName}>{players[0]}</Text></View>
          <View style={styles.player}><View style={[styles.playerAvatar,{ backgroundColor:winner.color }]}><Text style={styles.playerFace}>{faces[winnerIndex%faces.length]}</Text></View><Text numberOfLines={1} style={styles.playerName}>{players[1]}</Text></View>
        </View>
        <View style={styles.statsCard}>
          <View style={styles.stat}><Text style={styles.statIcon}>⏱</Text><Text style={styles.statValue}>{winner.remaining.toLocaleString('fa-IR')}ث</Text><Text style={styles.statLabel}>زمان باقی</Text></View>
          <View style={styles.statDivider}/><View style={styles.stat}><Text style={[styles.statIcon,{color:theme.colors.green}]}>✓</Text><Text style={styles.statValue}>{winner.correctAnswers.toLocaleString('fa-IR')}</Text><Text style={styles.statLabel}>درست</Text></View>
          <View style={styles.statDivider}/><View style={styles.stat}><Text style={[styles.statIcon,{color:theme.colors.primary}]}>×</Text><Text style={styles.statValue}>{winner.skips.toLocaleString('fa-IR')}</Text><Text style={styles.statLabel}>رد</Text></View>
        </View>
        <View style={styles.miniStandings}>{ordered.slice(0,3).map((t,i)=><View key={t.id} style={[styles.miniTeam,i===0&&styles.miniTeamWinner]}><View style={[styles.miniDot,{backgroundColor:t.color}]}/><Text numberOfLines={1} style={[styles.miniName,{color:t.color}]}>{t.title}</Text><Text style={styles.miniMeta}>{t.remaining.toLocaleString('fa-IR')}ث</Text></View>)}</View>
      </Animated.View>
      <View style={styles.bottom}>
        <Pressable onPress={() => { select(); onRematch(); }} style={({pressed})=>[styles.rematch,pressed&&styles.pressed]}><LinearGradient colors={['#FF5B7F','#FF3E63']} style={styles.rematchGradient}><Text style={styles.rematchText}>دوباره</Text><View style={styles.playBubble}><Text style={styles.playText}>▶</Text></View></LinearGradient></Pressable>
        <View style={styles.secondaryRow}><Pressable onPress={() => { select(); setDetailsOpen(true); }} style={({pressed})=>[styles.secondary,pressed&&styles.pressed]}><Text style={styles.secondaryIcon}>▥</Text><Text style={styles.secondaryText}>نتیجه کامل</Text></Pressable><Pressable onPress={() => { select(); onEditTeams(); }} style={({pressed})=>[styles.secondary,pressed&&styles.pressed]}><Text style={styles.secondaryIcon}>⇄</Text><Text style={styles.secondaryText}>تغییر تیم‌ها</Text></Pressable></View>
      </View>
      {detailsOpen ? <View style={styles.sheetScrim}><Pressable style={StyleSheet.absoluteFill} onPress={()=>setDetailsOpen(false)}/><View style={styles.sheet}><View style={styles.sheetHandle}/><Text style={styles.sheetTitle}>نتیجه بازی</Text><ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.rankList}>{ordered.map((item,index)=><View key={item.id} style={[styles.rankRow,index===0&&{backgroundColor:`${item.color}12`,borderColor:`${item.color}45`}]}><View style={[styles.rankNumber,{backgroundColor:index===0?item.color:'#FFF3DD'}]}><Text style={[styles.rankNumberText,index===0&&{color:'#fff'}]}>{(index+1).toLocaleString('fa-IR')}</Text></View><View style={styles.rankCopy}><Text numberOfLines={2} style={[styles.rankName,{color:item.color}]}>{item.title}</Text><Text style={styles.rankStats}>{item.correctAnswers.toLocaleString('fa-IR')} درست · {item.skips.toLocaleString('fa-IR')} رد</Text></View><Text style={styles.rankMeta}>{item.eliminatedRound?`راند ${item.eliminatedRound.toLocaleString('fa-IR')}`:`${item.remaining.toLocaleString('fa-IR')} ثانیه`}</Text></View>)}</ScrollView></View></View> : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:theme.colors.bg,paddingHorizontal:18,paddingTop:16,paddingBottom:14,justifyContent:'space-between',overflow:'hidden'}, sun:{position:'absolute',width:520,height:520,borderRadius:260,backgroundColor:'rgba(255,202,61,.11)',top:70,left:'50%',marginLeft:-260}, confetti:{position:'absolute',width:12,height:6,borderRadius:4}, pressed:{opacity:.84,transform:[{scale:.985}]},
  hero:{flex:1,alignItems:'center',justifyContent:'center'}, winWord:{color:theme.colors.primaryStrong,fontFamily:theme.fonts.black,fontSize:48,lineHeight:78,writingDirection:'rtl',textShadowColor:'#fff',textShadowRadius:3,textShadowOffset:{width:0,height:2}}, trophyWrap:{width:220,height:220,alignItems:'center',justifyContent:'center',marginTop:-5}, trophyDisc:{width:175,height:175,borderRadius:88,borderWidth:7,borderColor:'rgba(255,255,255,.88)',alignItems:'center',justifyContent:'center',shadowColor:'#E69A2F',shadowOpacity:.2,shadowRadius:16,shadowOffset:{width:0,height:8}}, trophyEmoji:{fontSize:102}, ribbon:{position:'absolute',bottom:3,minWidth:150,maxWidth:210,minHeight:51,borderRadius:25,paddingHorizontal:20,alignItems:'center',justifyContent:'center',borderWidth:4,borderColor:'#FFF4D9'}, ribbonText:{color:'#fff',fontFamily:theme.fonts.black,fontSize:20,lineHeight:37,textAlign:'center',writingDirection:'rtl'},
  playersRow:{flexDirection:'row-reverse',gap:34,marginTop:6},player:{alignItems:'center',width:74},playerAvatar:{width:55,height:55,borderRadius:28,borderWidth:4,borderColor:'#fff',alignItems:'center',justifyContent:'center'},playerFace:{fontSize:29},playerName:{color:theme.colors.textStrong,fontFamily:theme.fonts.bold,fontSize:10,lineHeight:20,marginTop:3,textAlign:'center'},
  statsCard:{minHeight:72,width:'92%',marginTop:13,borderRadius:22,backgroundColor:'#FFFDF8',borderWidth:1.5,borderColor:theme.colors.border,flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-around',paddingHorizontal:8,shadowColor:'#C68A53',shadowOpacity:.08,shadowRadius:9,shadowOffset:{width:0,height:5}},stat:{flex:1,alignItems:'center'},statIcon:{fontSize:16,color:theme.colors.blue},statValue:{color:theme.colors.textStrong,fontFamily:theme.fonts.black,fontSize:12,lineHeight:23},statLabel:{color:theme.colors.muted,fontFamily:theme.fonts.medium,fontSize:8,lineHeight:16},statDivider:{width:1,height:36,backgroundColor:'#EEE1D5'},
  miniStandings:{width:'92%',flexDirection:'row-reverse',gap:6,marginTop:8},miniTeam:{flex:1,minHeight:38,borderRadius:19,backgroundColor:'rgba(255,255,255,.82)',borderWidth:1,borderColor:theme.colors.border,flexDirection:'row-reverse',alignItems:'center',justifyContent:'center',gap:4,paddingHorizontal:5},miniTeamWinner:{borderColor:'#F3BE36'},miniDot:{width:7,height:7,borderRadius:4},miniName:{fontFamily:theme.fonts.black,fontSize:8.5,lineHeight:17,writingDirection:'rtl',maxWidth:55},miniMeta:{color:theme.colors.muted,fontFamily:theme.fonts.bold,fontSize:7.4,lineHeight:15},
  bottom:{gap:8},rematch:{minHeight:62,borderRadius:31,overflow:'hidden',borderWidth:4,borderColor:'#FFF0F3',shadowColor:theme.colors.primaryStrong,shadowOpacity:.22,shadowRadius:14,shadowOffset:{width:0,height:8}},rematchGradient:{flex:1,minHeight:62,paddingHorizontal:17,flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between'},rematchText:{color:'#fff',fontFamily:theme.fonts.black,fontSize:20,lineHeight:39,writingDirection:'rtl'},playBubble:{width:43,height:43,borderRadius:22,backgroundColor:'rgba(255,255,255,.22)',alignItems:'center',justifyContent:'center'},playText:{color:'#fff',fontSize:20},secondaryRow:{flexDirection:'row-reverse',gap:8},secondary:{flex:1,minHeight:47,borderRadius:23,borderWidth:1.3,borderColor:theme.colors.border,backgroundColor:'rgba(255,255,255,.82)',flexDirection:'row-reverse',alignItems:'center',justifyContent:'center',gap:6},secondaryIcon:{color:theme.colors.violet,fontSize:16},secondaryText:{color:theme.colors.textStrong,fontFamily:theme.fonts.black,fontSize:10.5,lineHeight:22,writingDirection:'rtl'},
  sheetScrim:{position:'absolute',top:0,right:0,bottom:0,left:0,backgroundColor:theme.colors.scrim,justifyContent:'flex-end',zIndex:20},sheet:{maxHeight:'78%',backgroundColor:'#FFFDF8',borderTopLeftRadius:31,borderTopRightRadius:31,paddingHorizontal:20,paddingTop:10,paddingBottom:24},sheetHandle:{width:42,height:5,borderRadius:3,backgroundColor:'#DCCFC5',alignSelf:'center',marginBottom:12},sheetTitle:{color:theme.colors.textStrong,fontFamily:theme.fonts.black,fontSize:22,lineHeight:40,textAlign:'right',writingDirection:'rtl',marginBottom:7},rankList:{paddingBottom:6,gap:7},rankRow:{minHeight:70,flexDirection:'row-reverse',alignItems:'center',gap:10,borderWidth:1,borderColor:theme.colors.border,borderRadius:20,paddingVertical:8,paddingHorizontal:10,backgroundColor:'#FFF9F1'},rankNumber:{width:37,height:37,borderRadius:19,alignItems:'center',justifyContent:'center'},rankNumberText:{color:theme.colors.text,fontFamily:theme.fonts.black,fontSize:11},rankCopy:{flex:1,minWidth:0,alignItems:'flex-end'},rankName:{fontFamily:theme.fonts.extraBold,fontSize:13.5,lineHeight:27,textAlign:'right',writingDirection:'rtl'},rankStats:{color:theme.colors.muted,fontFamily:theme.fonts.medium,fontSize:8.8,lineHeight:18,writingDirection:'rtl'},rankMeta:{minWidth:58,maxWidth:86,color:theme.colors.muted,fontFamily:theme.fonts.medium,fontSize:8.6,lineHeight:18,textAlign:'left'},
});
