import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { PrimaryButton, Screen, SectionTitle, TopNav } from '../components/UI';
import { theme } from '../theme';

const rules = [
  { n: '۱', title: 'توضیح بده', body: 'خود کلمه و مشتقاتش ممنوع؛ بقیه راه‌ها آزاده.', icon: '💬', color: theme.colors.primary },
  { n: '۲', title: 'حدس زد؟ پاس بده', body: 'روی دایره بزن و گوشی رو همون لحظه بده تیم بعد.', icon: '☝️', color: theme.colors.blue },
  { n: '۳', title: 'بمب نگه ندار', body: 'راند که تموم بشه، از ذخیره زمان کم می‌شه.', icon: '💣', color: theme.colors.green },
];
const small = [
  { title: 'رد کردن', body: 'اگه گیر کردی، رد کن؛ چند ثانیه اول قفله.', icon: '✋', color: theme.colors.orange },
  { title: 'بونس', body: 'کلمه‌های متوسط و سخت می‌تونن زمان برگردونن.', icon: '🏆', color: theme.colors.violet },
  { title: 'برد', body: 'آخرین تیمی که هنوز زمان داره، برنده‌ست.', icon: '🚩', color: theme.colors.green },
];

export function RulesScreen({ onBack, onStart }: { onBack: () => void; onStart: () => void }) {
  return (
    <Screen style={styles.screen}>
      <TopNav onBack={onBack} />
      <SectionTitle center title="سه قانون، همین." subtitle="کمتر بخون، سریع‌تر بازی کن." />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
      <View style={styles.rules}>
        {rules.map((rule) => (
          <View key={rule.n} style={styles.ruleCard}>
            <View style={[styles.number, { backgroundColor: rule.color }]}><Text style={styles.numberText}>{rule.n}</Text></View>
            <View style={styles.ruleCopy}><Text maxFontSizeMultiplier={1} style={[styles.ruleTitle, { color: rule.color }]}>{rule.title}</Text><Text maxFontSizeMultiplier={1} style={styles.ruleBody}>{rule.body}</Text></View>
            <View style={[styles.ruleIcon, { backgroundColor: `${rule.color}22` }]}><Text style={styles.ruleEmoji}>{rule.icon}</Text></View>
          </View>
        ))}
      </View>
      <View style={styles.miniList}>
        {small.map((item) => (
          <View key={item.title} style={styles.miniRow}>
            <View style={[styles.miniIcon, { backgroundColor: `${item.color}25` }]}><Text style={styles.miniEmoji}>{item.icon}</Text></View>
            <View style={styles.miniCopy}><Text maxFontSizeMultiplier={1} style={[styles.miniTitle, { color: item.color }]}>{item.title}</Text><Text maxFontSizeMultiplier={1} style={styles.miniBody}>{item.body}</Text></View>
          </View>
        ))}
      </View>
      </ScrollView>
      <PrimaryButton label="تیم‌ها رو بچین" onPress={onStart} icon="▶" />
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { paddingBottom: 12 }, scroll: { paddingBottom: 12 }, rules: { gap: 10 },
  ruleCard: { minHeight: 119, borderRadius: 27, backgroundColor: '#FFFDF8', borderWidth: 1.5, borderColor: theme.colors.border, flexDirection: 'row-reverse', alignItems: 'center', gap: 11, paddingHorizontal: 12, paddingVertical: 10, shadowColor: '#C68A53', shadowOpacity: .10, shadowRadius: 10, shadowOffset: { width: 0, height: 6 }, elevation: 2 },
  number: { width: 52, height: 52, borderRadius: 26, borderWidth: 4, borderColor: '#fff', alignItems: 'center', justifyContent: 'center', shadowColor: '#8B6146', shadowOpacity: .08, shadowRadius: 5, shadowOffset: { width: 0, height: 3 } }, numberText: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 21, lineHeight: 34 },
  ruleCopy: { flex: 1, alignItems: 'flex-end', minWidth: 0 }, ruleTitle: { width: '100%', fontFamily: theme.fonts.black, fontSize: 19, lineHeight: 38, textAlign: 'right', writingDirection: 'rtl', paddingTop: 1, paddingBottom: 2 }, ruleBody: { width: '100%', color: theme.colors.textStrong, fontFamily: theme.fonts.medium, fontSize: 10.7, lineHeight: 24, textAlign: 'right', writingDirection: 'rtl', paddingVertical: 1 },
  ruleIcon: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center' }, ruleEmoji: { fontSize: 39 },
  miniList: { gap: 7, paddingVertical: 10 }, miniRow: { minHeight: 52, borderRadius: 22, backgroundColor: 'rgba(255,255,255,.84)', borderWidth: 1, borderColor: theme.colors.border, flexDirection: 'row-reverse', alignItems: 'center', gap: 9, paddingHorizontal: 10, paddingVertical: 6 }, miniIcon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' }, miniEmoji: { fontSize: 21 }, miniCopy: { flex: 1, minWidth: 0, alignItems: 'flex-end' }, miniTitle: { fontFamily: theme.fonts.black, fontSize: 12.5, lineHeight: 24, writingDirection: 'rtl' }, miniBody: { maxWidth: '100%', color: theme.colors.text, fontFamily: theme.fonts.medium, fontSize: 9.2, lineHeight: 19, textAlign: 'right', writingDirection: 'rtl' },
});
