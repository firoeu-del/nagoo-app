import { GameMode } from '../types';

export const gameModes: Record<GameMode, {
  title: string;
  subtitle: string;
  badge: string;
  roundSeconds: number;
  skipUnlockSeconds: number;
  hiddenClock: boolean;
}> = {
  classic: {
    title: 'کلاسیک',
    subtitle: 'ریتم اصلی نگو!؛ سریع، منصفانه و مناسب هر جمع',
    badge: '۲۰ ثانیه',
    roundSeconds: 20,
    skipUnlockSeconds: 5,
    hiddenClock: false,
  },
  mystery: {
    title: 'بمب مخفی',
    subtitle: 'زمان دقیق دیده نمی‌شود؛ فقط فشار و ضربان بیشتر می‌شود',
    badge: '۱۶–۲۴ ثانیه',
    roundSeconds: 20,
    skipUnlockSeconds: 5,
    hiddenClock: true,
  },
  turbo: {
    title: 'توربو',
    subtitle: 'راندهای کوتاه‌تر و تصمیم‌های فوری برای جمع‌های پرانرژی',
    badge: '۱۲ ثانیه',
    roundSeconds: 12,
    skipUnlockSeconds: 3,
    hiddenClock: false,
  },
};

export function resolveRoundSeconds(mode: GameMode) {
  if (mode === 'mystery') return 16 + Math.floor(Math.random() * 9);
  return gameModes[mode].roundSeconds;
}
