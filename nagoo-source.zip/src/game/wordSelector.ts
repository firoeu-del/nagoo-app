import { GameWord, WordCategory, WordDifficulty } from '../types';

export type WordSelectionMemory = {
  seenIds: Set<string>;
  categoryUsage: Partial<Record<WordCategory, number>>;
  recentCategories: WordCategory[];
  seenTexts: Set<string>;
};

export function createWordSelectionMemory(): WordSelectionMemory {
  return {
    seenIds: new Set<string>(),
    categoryUsage: {},
    recentCategories: [],
    seenTexts: new Set<string>(),
  };
}

export function resetWordSelectionMemory(memory: WordSelectionMemory) {
  memory.seenIds.clear();
  memory.categoryUsage = {};
  memory.recentCategories = [];
  memory.seenTexts.clear();
}

function normalizeText(value: string) {
  return value
    .replace(/\u200c/g, ' ')
    .replace(/[يى]/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\s+/g, ' ')
    .trim()
    .toLocaleLowerCase('fa');
}

function randomItem<T>(items: T[]): T {
  return items[Math.floor(Math.random() * items.length)];
}

function chooseDifficulty(words: GameWord[]): WordDifficulty {
  const available = (['normal', 'hard', 'veryHard'] as WordDifficulty[])
    .filter((difficulty) => words.some((word) => word.difficulty === difficulty));
  return randomItem(available.length ? available : ['normal']);
}

function chooseBalancedCategory(words: GameWord[], memory: WordSelectionMemory): WordCategory {
  const categories = Array.from(new Set(words.map((word) => word.category)));
  if (categories.length === 1) return categories[0];

  const last = memory.recentCategories[memory.recentCategories.length - 1];
  const withoutImmediateRepeat = categories.filter((category) => category !== last);
  const source = withoutImmediateRepeat.length ? withoutImmediateRepeat : categories;

  const usages = source.map((category) => memory.categoryUsage[category] ?? 0);
  const minUsage = Math.min(...usages);

  // Pick only among the least-used categories so large packs never dominate the match.
  const balanced = source.filter((category) => (memory.categoryUsage[category] ?? 0) === minUsage);
  return randomItem(balanced.length ? balanced : source);
}

/**
 * Smart selector for party pacing:
 * - No exact ID repeats until the active pool is exhausted.
 * - Categories stay roughly balanced, regardless of pack size.
 * - Avoids the same category twice in a row when possible.
 * - Avoids normalized-text repeats across categories for the whole pool cycle.
 * - Respects the user-selected difficulty matrix; active levels rotate naturally.
 */
export function pickSmartWord(pool: GameWord[], memory: WordSelectionMemory): GameWord {
  if (!pool.length) throw new Error('No eligible words are available.');

  let unseen = pool.filter((word) => !memory.seenIds.has(word.id));
  if (!unseen.length) {
    memory.seenIds.clear();
    memory.categoryUsage = {};
    unseen = pool;
  }

  let candidates = unseen.filter((word) => !memory.seenTexts.has(normalizeText(word.text)));
  if (!candidates.length) {
    memory.seenIds.clear();
    memory.seenTexts.clear();
    memory.categoryUsage = {};
    unseen = pool;
    candidates = unseen;
  }

  const category = chooseBalancedCategory(candidates, memory);
  const inCategory = candidates.filter((word) => word.category === category);
  const difficulty = chooseDifficulty(inCategory);
  const sameDifficulty = inCategory.filter((word) => word.difficulty === difficulty);
  const selected = randomItem(sameDifficulty.length ? sameDifficulty : inCategory);

  memory.seenIds.add(selected.id);
  memory.categoryUsage[category] = (memory.categoryUsage[category] ?? 0) + 1;
  memory.recentCategories.push(category);
  memory.recentCategories = memory.recentCategories.slice(-3);
  memory.seenTexts.add(normalizeText(selected.text));

  return selected;
}
