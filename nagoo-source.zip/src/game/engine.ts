import { GameWord, TeamState, WordDifficulty } from '../types';

export function getDifficultyBonus(difficulty: WordDifficulty) {
  if (difficulty === 'veryHard') return 4;
  if (difficulty === 'hard') return 2;
  return 0;
}

export function applyCorrectAnswer(
  teams: TeamState[],
  teamIndex: number,
  word: GameWord,
  maxReserve: number,
  bonusesEnabled: boolean,
) {
  const bonus = bonusesEnabled ? getDifficultyBonus(word.difficulty) : 0;

  return teams.map((team, index) => {
    if (index !== teamIndex) return team;
    const nextRemaining = bonus ? Math.min(maxReserve, team.remaining + bonus) : team.remaining;
    const appliedBonus = Math.max(0, nextRemaining - team.remaining);
    return {
      ...team,
      remaining: nextRemaining,
      correctAnswers: team.correctAnswers + 1,
      bonusSeconds: team.bonusSeconds + appliedBonus,
    };
  });
}

export function applySkip(teams: TeamState[], teamIndex: number) {
  return teams.map((team, index) => index === teamIndex ? { ...team, skips: team.skips + 1 } : team);
}

export function applyRoundLoss(
  teams: TeamState[],
  teamIndex: number,
  penaltySeconds: number,
  roundNumber: number,
) {
  return teams.map((team, index) => {
    if (index !== teamIndex) return team;
    const remaining = Math.max(0, team.remaining - penaltySeconds);
    const eliminated = remaining === 0;
    return {
      ...team,
      remaining,
      eliminated,
      eliminatedRound: eliminated ? roundNumber : team.eliminatedRound,
      losses: team.losses + 1,
    };
  });
}

export function nextAliveTeamIndex(teams: TeamState[], current: number) {
  for (let offset = 1; offset <= teams.length; offset += 1) {
    const index = (current + offset) % teams.length;
    if (!teams[index].eliminated) return index;
  }
  return current;
}

export function aliveTeams(teams: TeamState[]) {
  return teams.filter((team) => !team.eliminated);
}

export function finalStandings(teams: TeamState[]) {
  return teams.slice().sort((a, b) => {
    if (!a.eliminated && b.eliminated) return -1;
    if (a.eliminated && !b.eliminated) return 1;
    if (!a.eliminated && !b.eliminated) return b.remaining - a.remaining;
    return (b.eliminatedRound ?? -1) - (a.eliminatedRound ?? -1);
  });
}
