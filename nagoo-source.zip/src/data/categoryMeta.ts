import { WordCategory, WordDifficulty } from '../types';
import { theme } from '../theme';

export const playableCategories: WordCategory[] = [
  'general','iran','nostalgia','cinema','music','famous','sports','food','brands','jobs','objects','places','hard','adult',
];

export const categoryArt: Record<WordCategory, { mark: string; accent: string; blurb: string }> = {
  general: { mark: 'ALL', accent: '#55D6FF', blurb: 'چیزهایی که همه می‌شناسیم' },
  iran: { mark: 'IR', accent: '#62DCA0', blurb: 'آدم‌ها، جاها و فرهنگ ایرانی' },
  nostalgia: { mark: 'RET', accent: '#FFD166', blurb: 'خاطره‌های قدیمی و نوستالژیک' },
  cinema: { mark: 'FILM', accent: '#947CFF', blurb: 'فیلم، سریال و دنیای تصویر' },
  music: { mark: 'MUS', accent: '#FF5C7C', blurb: 'خواننده، آهنگ و موسیقی' },
  famous: { mark: 'STAR', accent: '#FFD166', blurb: 'چهره‌های معروف ایرانی و جهانی' },
  sports: { mark: 'SP', accent: '#62DCA0', blurb: 'ورزش، تیم و ورزشکار' },
  food: { mark: 'FOOD', accent: '#FF9A5F', blurb: 'غذا، خوراکی و آشپزی' },
  brands: { mark: 'BR', accent: '#55D6FF', blurb: 'برندها و محصولات آشنا' },
  jobs: { mark: 'JOB', accent: '#947CFF', blurb: 'شغل‌ها و حرفه‌ها' },
  objects: { mark: 'OBJ', accent: '#55D6FF', blurb: 'وسایل و چیزهای اطرافمان' },
  places: { mark: 'MAP', accent: '#62DCA0', blurb: 'شهر، کشور و مکان‌های معروف' },
  hard: { mark: 'PRO', accent: '#FF5C7C', blurb: 'مفاهیم سخت‌تر برای حرفه‌ای‌ها' },
  adult: { mark: '18', accent: '#FF4B63', blurb: 'پک صریح و فقط برای بزرگسالان' },
  custom: { mark: '+', accent: '#55D6FF', blurb: 'کلمات اختصاصی جمع شما' },
};

export const difficultyMeta: Record<WordDifficulty, { label: string; color: string }> = {
  normal: { label: 'آسان', color: theme.colors.lime },
  hard: { label: 'متوسط', color: theme.colors.yellow },
  veryHard: { label: 'سخت', color: theme.colors.primary },
};
