export type ScreenName = 'home' | 'rules' | 'teams' | 'settings' | 'packs' | 'custom' | 'game' | 'results';

export type WordDifficulty = 'normal' | 'hard' | 'veryHard';
export type GameMode = 'classic' | 'mystery' | 'turbo';

export type WordCategory =
  | 'general'
  | 'cinema'
  | 'famous'
  | 'sports'
  | 'food'
  | 'objects'
  | 'places'
  | 'hard'
  | 'adult'
  | 'iran'
  | 'nostalgia'
  | 'music'
  | 'brands'
  | 'jobs'
  | 'custom';

export type GameWord = {
  id: string;
  text: string;
  category: WordCategory;
  difficulty: WordDifficulty;
};

export type TeamDraft = {
  id: string;
  title: string;
  player1: string;
  player2: string;
  color: string;
};

export type TeamState = TeamDraft & {
  remaining: number;
  describerIndex: 0 | 1;
  eliminated: boolean;
  losses: number;
  correctAnswers: number;
  skips: number;
  bonusSeconds: number;
  eliminatedRound: number | null;
};

export type DifficultyMatrix = Partial<Record<WordCategory, WordDifficulty[]>>;

export type GameSettings = {
  contentVersion: number;
  reserveSeconds: number;
  roundSeconds: number;
  skipUnlockSeconds: number;
  categories: WordCategory[];
  difficultyMatrix: DifficultyMatrix;
  gameMode: GameMode;
  hardWordBonuses: boolean;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
};

export type CustomWord = {
  id: string;
  text: string;
  difficulty: WordDifficulty;
};
