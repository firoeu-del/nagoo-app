import { CustomWord, GameSettings, TeamDraft } from './types';

const KEYS = {
  customWords: 'nagoo.customWords.v1',
  settings: 'nagoo.settings.v1',
  teams: 'nagoo.teams.v1',
};

function readJson<T>(key: string, fallback: T): T {
  try {
    const value = globalThis.localStorage?.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  try {
    globalThis.localStorage?.setItem(key, JSON.stringify(value));
  } catch {
    // Private browsing or a full storage quota should not interrupt the game.
  }
}

export async function loadCustomWords(): Promise<CustomWord[]> {
  return readJson(KEYS.customWords, []);
}

export async function saveCustomWords(words: CustomWord[]) {
  writeJson(KEYS.customWords, words);
}

export async function loadSettings(): Promise<GameSettings | null> {
  return readJson<GameSettings | null>(KEYS.settings, null);
}

export async function saveSettings(settings: GameSettings) {
  writeJson(KEYS.settings, settings);
}

export async function loadTeams(): Promise<TeamDraft[] | null> {
  return readJson<TeamDraft[] | null>(KEYS.teams, null);
}

export async function saveTeams(teams: TeamDraft[]) {
  writeJson(KEYS.teams, teams);
}
