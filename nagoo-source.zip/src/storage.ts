import Storage from 'expo-sqlite/kv-store';
import { Platform } from 'react-native';
import { CustomWord, GameSettings, TeamDraft } from './types';

const KEYS = {
  customWords: 'nagoo.customWords.v1',
  settings: 'nagoo.settings.v1',
  teams: 'nagoo.teams.v1',
};

const webStorage = {
  async getItem(key: string) {
    return typeof localStorage === 'undefined' ? null : localStorage.getItem(key);
  },
  async setItem(key: string, value: string) {
    if (typeof localStorage !== 'undefined') localStorage.setItem(key, value);
  },
};

const persistentStorage = Platform.OS === 'web' ? webStorage : Storage;

export async function loadCustomWords(): Promise<CustomWord[]> {
  try {
    const value = await persistentStorage.getItem(KEYS.customWords);
    return value ? JSON.parse(value) : [];
  } catch {
    return [];
  }
}

export async function saveCustomWords(words: CustomWord[]) {
  await persistentStorage.setItem(KEYS.customWords, JSON.stringify(words));
}

export async function loadSettings(): Promise<GameSettings | null> {
  try {
    const value = await persistentStorage.getItem(KEYS.settings);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

export async function saveSettings(settings: GameSettings) {
  await persistentStorage.setItem(KEYS.settings, JSON.stringify(settings));
}

export async function loadTeams(): Promise<TeamDraft[] | null> {
  try {
    const value = await persistentStorage.getItem(KEYS.teams);
    return value ? JSON.parse(value) : null;
  } catch {
    return null;
  }
}

export async function saveTeams(teams: TeamDraft[]) {
  await persistentStorage.setItem(KEYS.teams, JSON.stringify(teams));
}
