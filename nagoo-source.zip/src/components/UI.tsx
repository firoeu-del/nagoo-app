import React from 'react';
import { Platform, Pressable, SafeAreaView, StatusBar, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { theme } from '../theme';

export function Screen({ children, style, ambient = true }: { children: React.ReactNode; style?: ViewStyle; ambient?: boolean }) {
  return <SafeAreaView style={styles.safe}><View style={[styles.screen, style]}>{ambient ? <Ambient /> : null}{children}</View></SafeAreaView>;
}

export function Ambient() {
  const bits = [
    ['8%','7%', theme.colors.primary,'20deg'], ['14%','84%', theme.colors.cyan,'-16deg'], ['25%','91%', theme.colors.yellow,'36deg'],
    ['35%','5%', theme.colors.mint,'12deg'], ['49%','93%', theme.colors.green,'-24deg'], ['63%','7%', theme.colors.purple,'42deg'],
    ['75%','88%', theme.colors.coral,'15deg'], ['88%','13%', theme.colors.sky,'-28deg'], ['91%','71%', theme.colors.yellow,'18deg'],
    ['5%','57%', theme.colors.green,'70deg'], ['20%','28%', theme.colors.orange,'-48deg'], ['54%','17%', theme.colors.primary,'12deg'],
  ] as const;
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <LinearGradient colors={['#FFF0C2', '#FFF7E2', '#FFF1CC']} locations={[0, 0.48, 1]} style={StyleSheet.absoluteFill} />
      <View style={styles.sunGlow} />
      <View style={styles.sunGlow2} />
      {bits.map(([top,left,color,rotate], index) => <View key={index} style={[styles.confetti, { top, left, backgroundColor: color, transform: [{ rotate }] }]} />)}
      <Text style={[styles.doodle, { top: '19%', right: '5%', color: theme.colors.yellow }]}>★</Text>
      <Text style={[styles.doodle, { top: '72%', left: '4%', color: theme.colors.purple }]}>〜</Text>
      <Text style={[styles.doodle, { top: '42%', right: '6%', color: theme.colors.cyan }]}>?</Text>
    </View>
  );
}

export function TopNav({ onBack, rightLabel, onRight }: { onBack?: () => void; rightLabel?: string; onRight?: () => void }) {
  return <View style={styles.topNav}><View style={styles.topSlot}>{onBack ? <IconButton glyph="‹" onPress={onBack} /> : null}</View><View /><View style={[styles.topSlot, { alignItems: 'flex-end' }]}>{rightLabel && onRight ? <Pressable onPress={onRight} hitSlop={12} style={({ pressed }) => [styles.topActionWrap, pressed && styles.pressed]}><Text maxFontSizeMultiplier={1} style={styles.topAction}>{rightLabel}</Text></Pressable> : null}</View></View>;
}

export function IconButton({ glyph, onPress, danger = false }: { glyph: string; onPress: () => void; danger?: boolean }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.iconButton, danger && styles.iconButtonDanger, pressed && styles.pressed]}><Text maxFontSizeMultiplier={1} style={[styles.iconGlyph, danger && { color: theme.colors.danger }]}>{glyph}</Text></Pressable>;
}

export function PrimaryButton({ label, onPress, disabled = false, compact = false, icon = '»' }: { label: string; onPress: () => void; disabled?: boolean; compact?: boolean; icon?: string }) {
  return (
    <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.primaryShell, compact && styles.primaryCompact, pressed && !disabled && styles.pressed, disabled && { opacity: 0.36 }]}>
      <LinearGradient colors={['#8F68FF', '#6A38F5']} start={{ x: 0.05, y: 0 }} end={{ x: 0.95, y: 1 }} style={[styles.primaryGradient, compact && styles.primaryGradientCompact]}>
        <Text maxFontSizeMultiplier={1} style={[styles.primaryLabel, compact && styles.primaryLabelCompact]}>{label}</Text>
        <View style={[styles.primaryArrow, compact && styles.primaryArrowCompact]}><Text maxFontSizeMultiplier={1} style={styles.primaryArrowText}>{icon}</Text></View>
      </LinearGradient>
    </Pressable>
  );
}

export function GhostButton({ label, onPress }: { label: string; onPress: () => void }) { return <Pressable onPress={onPress} style={({ pressed }) => [styles.ghost, pressed && styles.pressed]}><Text maxFontSizeMultiplier={1} style={styles.ghostText}>{label}</Text></Pressable>; }

export function SectionTitle({ kicker, title, subtitle, center = false }: { kicker?: string; title: string; subtitle?: string; center?: boolean }) {
  return <View style={[styles.sectionTitle, center && { alignItems: 'center' }]}>{kicker ? <Text maxFontSizeMultiplier={1} style={[styles.kicker, center && { textAlign: 'center' }]}>{kicker}</Text> : null}<Text maxFontSizeMultiplier={1} style={[styles.heading, center && { textAlign: 'center' }]}>{title}</Text>{subtitle ? <Text maxFontSizeMultiplier={1} style={[styles.subtitle, center && { textAlign: 'center', alignSelf: 'center' }]}>{subtitle}</Text> : null}</View>;
}

export function Pill({ label, active = false, onPress, color = theme.colors.primary }: { label: string; active?: boolean; onPress?: () => void; color?: string }) {
  const body = <View style={[styles.pill, active && { borderColor: `${color}55`, backgroundColor: `${color}14` }]}>{active ? <View style={[styles.pillDot, { backgroundColor: color }]} /> : null}<Text maxFontSizeMultiplier={1} style={[styles.pillText, active && { color: theme.colors.textStrong }]}>{label}</Text></View>;
  return onPress ? <Pressable onPress={onPress} style={({ pressed }) => pressed && styles.pressed}>{body}</Pressable> : body;
}
export function GlassCard({ children, style }: { children: React.ReactNode; style?: ViewStyle }) { return <View style={[styles.glass, style]}>{children}</View>; }
export const Button = ({ label, onPress, variant = 'primary', disabled = false, compact = false }: any) => variant === 'primary' ? <PrimaryButton label={label} onPress={onPress} disabled={disabled} compact={compact} /> : <GhostButton label={label} onPress={onPress} />;
export const Chip = ({ label, active, onPress, accent }: any) => <Pill label={label} active={active} onPress={onPress} color={accent} />;
export const Card = GlassCard;
export function Badge({ label, tone = 'neutral' }: { label: string; tone?: 'neutral' | 'hot' | 'good' | 'warn' }) { const color = tone === 'hot' ? theme.colors.primary : tone === 'good' ? theme.colors.lime : tone === 'warn' ? theme.colors.yellow : theme.colors.muted; return <Pill label={label} active color={color} />; }
export function Header({ title, onBack, eyebrow }: { title: string; onBack?: () => void; eyebrow?: string }) { return <View><TopNav onBack={onBack} /><SectionTitle kicker={eyebrow} title={title} /></View>; }
export function Title({ children, eyebrow }: { children: React.ReactNode; small?: boolean; eyebrow?: string }) { return <SectionTitle kicker={eyebrow} title={String(children)} />; }

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.bg },
  screen: { flex: 1, backgroundColor: theme.colors.bg, paddingHorizontal: 18, paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight ?? 24) + 7 : 6, paddingBottom: 13, overflow: 'hidden' },
  sunGlow: { position: 'absolute', width: 620, height: 620, borderRadius: 310, backgroundColor: 'rgba(255,203,61,0.12)', top: 105, left: '50%', marginLeft: -310 },
  sunGlow2: { position: 'absolute', width: 390, height: 390, borderRadius: 195, backgroundColor: 'rgba(255,255,255,0.18)', top: 250, left: '50%', marginLeft: -195 },
  confetti: { position: 'absolute', width: 11, height: 6, borderRadius: 5 }, doodle: { position: 'absolute', fontSize: 23, fontFamily: theme.fonts.black },
  topNav: { minHeight: 50, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', zIndex: 5 }, topSlot: { width: 78 },
  topActionWrap: { backgroundColor: '#FFFDF8', borderWidth: 1.5, borderColor: 'rgba(255,91,127,0.20)', borderRadius: 23, paddingHorizontal: 15, paddingVertical: 6, shadowColor: '#D59867', shadowOpacity: 0.10, shadowRadius: 11, shadowOffset: { width: 0, height: 5 } },
  topAction: { color: theme.colors.coral, fontFamily: theme.fonts.bold, fontSize: 12, lineHeight: 25, writingDirection: 'rtl', paddingVertical: 1 },
  iconButton: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FFFDF8', borderWidth: 1.5, borderColor: theme.colors.border, shadowColor: '#C99162', shadowOpacity: 0.11, shadowRadius: 10, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
  iconButtonDanger: { backgroundColor: '#FFF0F3', borderColor: 'rgba(255,54,95,0.2)' }, iconGlyph: { color: theme.colors.textStrong, fontFamily: theme.fonts.black, fontSize: 25, lineHeight: 39, textAlignVertical: 'center', paddingVertical: 1 }, pressed: { opacity: 0.84, transform: [{ scale: 0.978 }] },
  primaryShell: { minHeight: 67, borderRadius: 34, overflow: 'hidden', shadowColor: '#6740DB', shadowOpacity: 0.28, shadowRadius: 16, shadowOffset: { width: 0, height: 9 }, elevation: 8, borderWidth: 4, borderColor: '#F0E8FF' },
  primaryCompact: { minHeight: 56, borderRadius: 28, borderWidth: 3 }, primaryGradient: { flex: 1, minHeight: 67, paddingHorizontal: 12, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' }, primaryGradientCompact: { minHeight: 56 },
  primaryLabel: { flexShrink: 1, color: '#fff', fontFamily: theme.fonts.black, fontSize: 20, lineHeight: 42, writingDirection: 'rtl', paddingRight: 14, paddingTop: 5, paddingBottom: 7 }, primaryLabelCompact: { fontSize: 17, lineHeight: 34 },
  primaryArrow: { width: 49, height: 49, borderRadius: 25, backgroundColor: 'rgba(255,255,255,0.17)', alignItems: 'center', justifyContent: 'center' }, primaryArrowCompact: { width: 39, height: 39, borderRadius: 20 }, primaryArrowText: { color: '#fff', fontFamily: theme.fonts.black, fontSize: 24, lineHeight: 34 },
  ghost: { minHeight: 46, alignItems: 'center', justifyContent: 'center' }, ghostText: { color: theme.colors.muted, fontFamily: theme.fonts.bold, fontSize: 12, lineHeight: 25, writingDirection: 'rtl', paddingVertical: 2 },
  sectionTitle: { width: '100%', alignItems: 'flex-end', marginTop: 0, marginBottom: 14, paddingTop: 1 }, kicker: { color: theme.colors.primary, fontFamily: theme.fonts.bold, fontSize: 11, lineHeight: 22, marginBottom: 1, writingDirection: 'rtl' },
  heading: { width: '100%', color: theme.colors.coral, fontFamily: theme.fonts.black, fontSize: 31, lineHeight: 54, letterSpacing: -0.4, textAlign: 'right', writingDirection: 'rtl', paddingTop: 3, paddingBottom: 4, includeFontPadding: true },
  subtitle: { width: '100%', color: theme.colors.textStrong, fontFamily: theme.fonts.medium, fontSize: 12, lineHeight: 25, marginTop: -1, textAlign: 'right', writingDirection: 'rtl', maxWidth: 390, paddingVertical: 2, includeFontPadding: true },
  pill: { minHeight: 40, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 7, borderRadius: 20, borderWidth: 1.2, borderColor: theme.colors.border, backgroundColor: 'rgba(255,255,255,0.88)', paddingHorizontal: 13, paddingVertical: 6 }, pillDot: { width: 7, height: 7, borderRadius: 4 }, pillText: { color: theme.colors.muted, fontFamily: theme.fonts.semibold, fontSize: 10.5, lineHeight: 21, writingDirection: 'rtl', paddingVertical: 1 },
  glass: { backgroundColor: '#FFFDF8', borderRadius: theme.radius.lg, borderWidth: 1.5, borderColor: theme.colors.border, padding: 16, shadowColor: '#C68A53', shadowOpacity: 0.10, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 2 },
});
