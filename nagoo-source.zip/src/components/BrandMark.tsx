import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { theme } from '../theme';

export function BrandMark({ size = 92 }: { size?: number }) {
  const fontSize = Math.round(size * 0.69);
  const lineHeight = Math.round(fontSize * 1.54);
  return (
    <View style={[styles.wrap, { width: size * 1.48, height: size * 1.06 }]}> 
      <Text maxFontSizeMultiplier={1} style={[styles.logoBack, { fontSize, lineHeight, transform: [{ translateX: -2 }, { translateY: 2 }, { rotate: '-2deg' }] }]}>نگو!</Text>
      <Text maxFontSizeMultiplier={1} style={[styles.logoBack, { fontSize, lineHeight, transform: [{ translateX: 2 }, { translateY: -1 }, { rotate: '-2deg' }] }]}>نگو!</Text>
      <Text maxFontSizeMultiplier={1} style={[styles.logo, { fontSize, lineHeight }]}>نگو!</Text>
      <View style={[styles.spark, { top: size * 0.07, right: size * 0.06, width: size * 0.11, backgroundColor: theme.colors.cyan, transform: [{ rotate: '-54deg' }] }]} />
      <View style={[styles.spark, { top: size * 0.18, right: -size * 0.01, width: size * 0.09, backgroundColor: theme.colors.yellow, transform: [{ rotate: '38deg' }] }]} />
      <View style={[styles.spark, { top: -size * 0.01, right: size * 0.18, width: size * 0.08, backgroundColor: theme.colors.green, transform: [{ rotate: '74deg' }] }]} />
      <View style={[styles.dot, { top: size * 0.02, left: size * 0.05, backgroundColor: theme.colors.primary }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center', overflow: 'visible' },
  logoBack: { position: 'absolute', color: '#FFFDF8', fontFamily: theme.fonts.black, textAlign: 'center', writingDirection: 'rtl', includeFontPadding: true, textShadowColor: 'rgba(180,72,63,0.12)', textShadowRadius: 8, textShadowOffset: { width: 0, height: 4 } },
  logo: { color: theme.colors.primaryStrong, fontFamily: theme.fonts.black, textAlign: 'center', writingDirection: 'rtl', includeFontPadding: true, transform: [{ rotate: '-2deg' }], textShadowColor: 'rgba(210,55,84,0.16)', textShadowRadius: 7, textShadowOffset: { width: 0, height: 5 } },
  spark: { position: 'absolute', height: 6, borderRadius: 9 },
  dot: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
});
