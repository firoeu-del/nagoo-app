import * as Haptics from 'expo-haptics';
import { useAudioPlayer } from 'expo-audio';
import { useCallback } from 'react';

function replay(player: ReturnType<typeof useAudioPlayer>, enabled: boolean) {
  if (!enabled) return;
  try {
    void player.seekTo(0);
    player.play();
  } catch {
    // Feedback is decorative. Gameplay must never depend on audio playback.
  }
}

export function useGameFeedback(soundEnabled = true, hapticsEnabled = true) {
  const tick = useAudioPlayer(require('../../assets/sounds/tick.wav'));
  const correctSound = useAudioPlayer(require('../../assets/sounds/correct.wav'));
  const skipSound = useAudioPlayer(require('../../assets/sounds/skip.wav'));
  const boomSound = useAudioPlayer(require('../../assets/sounds/boom.wav'));
  const winSound = useAudioPlayer(require('../../assets/sounds/win.wav'));

  const haptic = useCallback((action: () => Promise<void>) => {
    if (!hapticsEnabled) return;
    void action().catch(() => undefined);
  }, [hapticsEnabled]);

  const correct = useCallback(() => {
    replay(correctSound, soundEnabled);
    haptic(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success));
  }, [correctSound, haptic, soundEnabled]);

  const skip = useCallback(() => {
    replay(skipSound, soundEnabled);
    haptic(() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium));
  }, [skipSound, haptic, soundEnabled]);

  const countdown = useCallback((secondsLeft: number) => {
    replay(tick, soundEnabled);
    const style = secondsLeft <= 2 ? Haptics.ImpactFeedbackStyle.Heavy : Haptics.ImpactFeedbackStyle.Light;
    haptic(() => Haptics.impactAsync(style));
  }, [haptic, soundEnabled, tick]);

  const boom = useCallback(() => {
    replay(boomSound, soundEnabled);
    haptic(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error));
  }, [boomSound, haptic, soundEnabled]);

  const win = useCallback(() => {
    replay(winSound, soundEnabled);
    haptic(() => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success));
  }, [haptic, soundEnabled, winSound]);

  const select = useCallback(() => {
    haptic(() => Haptics.selectionAsync());
  }, [haptic]);

  return { correct, skip, countdown, boom, win, select };
}
