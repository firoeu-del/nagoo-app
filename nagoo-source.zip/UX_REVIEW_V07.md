# UX review — v0.7

## Pass 1 — Information architecture
- Removed decorative product metrics from Home.
- Removed persistent team-name form from the default path.
- Reduced Lobby to three primary decisions.
- Moved per-pack difficulty controls into one focused dock.
- Moved detailed final standings behind an explicit action.

## Pass 2 — Game feel
- Gameplay no longer uses a bordered dashboard card as the main stage.
- Team color now drives the live scene.
- The timer remains secondary until the final five seconds.
- Skip is contextual instead of occupying a large disabled card.
- Explosion auto-advances after a short dramatic beat.

## Pass 3 — Visual cleanup
- Removed English kickers from primary screens.
- Removed repeated large glass cards and repeated full-width gradient treatment.
- Rebuilt the brand mark as a circular word-bomb / speech mark.
- Tightened Vazirmatn hierarchy and RTL alignment.

## Pass 4 — Mobile layout
- Primary actions remain reachable at the bottom.
- Team grid works from 2–6 teams without horizontal swiping.
- Deck grid reserves bottom space for the floating difficulty dock.
- Gameplay has compact typography for devices under 700pt high.

## Pass 5 — Safety / edge cases
- Adult pack remains explicit opt-in.
- Pause and app-background timing behavior are preserved.
- Hidden-bomb mode does not expose countdown progress before urgency.
- Explosion manual-tap and auto-advance are guarded against double execution.
